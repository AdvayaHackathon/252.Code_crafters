
import React, { createContext, useState, useContext, ReactNode } from "react";

export type NavigationItem = 
  | "dashboard"
  | "classroom"
  | "live-lessons"
  | "recorded-lessons"
  | "assignments";

export type AlertType = {
  id: string;
  type: "warning" | "success" | "info" | "error";
  message: string;
  timestamp: Date;
  read: boolean;
};

export type AnalyticsType = {
  trendingStudents: { id: string; name: string; performance: "improving" | "declining" | "stable" }[];
  classPerformance: { classId: string; name: string; averageScore: number }[];
  recentActivity: { id: string; type: string; timestamp: Date; description: string }[];
};

type NavigationContextType = {
  activeItem: NavigationItem;
  setActiveItem: (item: NavigationItem) => void;
  isSidebarCollapsed: boolean;
  toggleSidebar: () => void;
  alerts: AlertType[];
  addAlert: (alert: Omit<AlertType, "id" | "timestamp" | "read">) => void;
  markAlertAsRead: (id: string) => void;
  analytics: AnalyticsType;
  updateAnalytics: (data: Partial<AnalyticsType>) => void;
};

const NavigationContext = createContext<NavigationContextType | undefined>(undefined);

export const NavigationProvider = ({ children }: { children: ReactNode }) => {
  const [activeItem, setActiveItem] = useState<NavigationItem>("dashboard");
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [alerts, setAlerts] = useState<AlertType[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsType>({
    trendingStudents: [],
    classPerformance: [],
    recentActivity: []
  });

  const toggleSidebar = () => {
    setIsSidebarCollapsed((prev) => !prev);
  };

  const addAlert = (alert: Omit<AlertType, "id" | "timestamp" | "read">) => {
    const newAlert: AlertType = {
      ...alert,
      id: Date.now().toString(),
      timestamp: new Date(),
      read: false
    };
    setAlerts(prev => [newAlert, ...prev]);
  };

  const markAlertAsRead = (id: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === id ? { ...alert, read: true } : alert
    ));
  };

  const updateAnalytics = (data: Partial<AnalyticsType>) => {
    setAnalytics(prev => ({ ...prev, ...data }));
  };

  return (
    <NavigationContext.Provider
      value={{
        activeItem,
        setActiveItem,
        isSidebarCollapsed,
        toggleSidebar,
        alerts,
        addAlert,
        markAlertAsRead,
        analytics,
        updateAnalytics
      }}
    >
      {children}
    </NavigationContext.Provider>
  );
};

export const useNavigation = () => {
  const context = useContext(NavigationContext);
  if (context === undefined) {
    throw new Error("useNavigation must be used within a NavigationProvider");
  }
  return context;
};
