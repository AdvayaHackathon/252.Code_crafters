
import React, { createContext, useState, useContext, ReactNode } from "react";

type User = {
  name: string;
  subject: string;
  isOnboarded: boolean;
};

type UserContextType = {
  user: User;
  updateUser: (data: Partial<User>) => void;
  isOnboarded: boolean;
  completeOnboarding: () => void;
};

const defaultUser: User = {
  name: "",
  subject: "",
  isOnboarded: false,
};

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User>(defaultUser);

  const updateUser = (data: Partial<User>) => {
    setUser((prev) => ({ ...prev, ...data }));
  };

  const completeOnboarding = () => {
    setUser((prev) => ({ ...prev, isOnboarded: true }));
  };

  return (
    <UserContext.Provider
      value={{
        user,
        updateUser,
        isOnboarded: user.isOnboarded,
        completeOnboarding,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error("useUser must be used within a UserProvider");
  }
  return context;
};
