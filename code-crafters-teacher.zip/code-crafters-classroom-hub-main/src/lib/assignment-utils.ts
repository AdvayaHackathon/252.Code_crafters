
// Simple plagiarism detection utility

export interface Assignment {
  id: string;
  title: string;
  content: string;
  studentId: string;
  studentName: string;
  submissionDate: Date;
  plagiarismScore?: number;
}

/**
 * Calculate similarity between two texts using Jaccard similarity
 */
export function calculateTextSimilarity(text1: string, text2: string): number {
  // Normalize texts
  const normalizedText1 = text1.toLowerCase().replace(/[^\w\s]/g, '');
  const normalizedText2 = text2.toLowerCase().replace(/[^\w\s]/g, '');
  
  // Create word sets
  const words1 = new Set(normalizedText1.split(/\s+/));
  const words2 = new Set(normalizedText2.split(/\s+/));
  
  // Calculate intersection
  const intersection = new Set([...words1].filter(x => words2.has(x)));
  
  // Calculate union
  const union = new Set([...words1, ...words2]);
  
  // Jaccard similarity coefficient
  if (union.size === 0) return 0;
  return intersection.size / union.size;
}

/**
 * Check plagiarism across multiple assignments
 * Returns the same assignments with plagiarism scores added
 */
export function checkPlagiarism(assignments: Assignment[]): Assignment[] {
  if (assignments.length <= 1) return assignments;

  return assignments.map(assignment => {
    // Compare with all other assignments
    let maxSimilarity = 0;
    
    for (const other of assignments) {
      if (other.id === assignment.id) continue;
      
      const similarity = calculateTextSimilarity(assignment.content, other.content);
      maxSimilarity = Math.max(maxSimilarity, similarity);
    }
    
    // Convert to percentage and round to 2 decimal places
    const plagiarismScore = Math.round(maxSimilarity * 100);
    
    return {
      ...assignment,
      plagiarismScore
    };
  });
}

/**
 * Determine if assignment has high plagiarism
 */
export function isPlagiarized(plagiarismScore?: number): boolean {
  if (plagiarismScore === undefined) return false;
  return plagiarismScore > 70; // Above 70% is considered plagiarized
}
