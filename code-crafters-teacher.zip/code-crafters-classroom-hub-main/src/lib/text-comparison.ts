
/**
 * Advanced text comparison utilities
 */

/**
 * Split text into sentences
 */
export function splitIntoSentences(text: string): string[] {
  // Handle common sentence endings with regex
  return text
    .replace(/([.?!])\s*(?=[A-Z])/g, "$1|")
    .split("|")
    .filter(Boolean)
    .map(s => s.trim());
}

/**
 * Normalize text for comparison
 */
export function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s]/g, '') // Remove punctuation
    .replace(/\s+/g, ' ') // Normalize whitespace
    .trim();
}

/**
 * Calculate cosine similarity between two texts
 */
export function calculateCosineSimilarity(text1: string, text2: string): number {
  // Normalize texts
  const normalizedText1 = normalizeText(text1);
  const normalizedText2 = normalizeText(text2);
  
  // Create term frequency maps
  const words1 = normalizedText1.split(' ');
  const words2 = normalizedText2.split(' ');
  
  const freqMap1: Record<string, number> = {};
  const freqMap2: Record<string, number> = {};
  
  words1.forEach(word => {
    freqMap1[word] = (freqMap1[word] || 0) + 1;
  });
  
  words2.forEach(word => {
    freqMap2[word] = (freqMap2[word] || 0) + 1;
  });
  
  // Get unique words from both texts
  const uniqueWords = new Set([...words1, ...words2]);
  
  // Calculate dot product
  let dotProduct = 0;
  let magnitude1 = 0;
  let magnitude2 = 0;
  
  uniqueWords.forEach(word => {
    const freq1 = freqMap1[word] || 0;
    const freq2 = freqMap2[word] || 0;
    
    dotProduct += freq1 * freq2;
    magnitude1 += freq1 * freq1;
    magnitude2 += freq2 * freq2;
  });
  
  // Calculate magnitudes
  magnitude1 = Math.sqrt(magnitude1);
  magnitude2 = Math.sqrt(magnitude2);
  
  // Avoid division by zero
  if (magnitude1 === 0 || magnitude2 === 0) return 0;
  
  // Calculate cosine similarity
  return dotProduct / (magnitude1 * magnitude2);
}

/**
 * Find longest common subsequence between two texts
 */
export function findCommonPhrases(text1: string, text2: string, minLength: number = 5): string[] {
  const words1 = normalizeText(text1).split(' ');
  const words2 = normalizeText(text2).split(' ');
  const commonPhrases: string[] = [];
  
  for (let i = 0; i < words1.length; i++) {
    for (let j = 0; j < words2.length; j++) {
      let k = 0;
      while (
        i + k < words1.length && 
        j + k < words2.length && 
        words1[i + k] === words2[j + k]
      ) {
        k++;
      }
      
      if (k >= minLength) {
        const phrase = words1.slice(i, i + k).join(' ');
        commonPhrases.push(phrase);
      }
    }
  }
  
  return commonPhrases;
}

/**
 * Generate a plagiarism report for two texts
 */
export function generatePlagiarismReport(text1: string, text2: string) {
  const similarity = calculateCosineSimilarity(text1, text2);
  const commonPhrases = findCommonPhrases(text1, text2);
  const similarityPercentage = Math.round(similarity * 100);
  
  return {
    similarityScore: similarityPercentage,
    commonPhrases,
    isPlagiarized: similarityPercentage > 70,
    confidence: similarityPercentage > 90 ? 'high' : 
                similarityPercentage > 70 ? 'medium' : 'low'
  };
}
