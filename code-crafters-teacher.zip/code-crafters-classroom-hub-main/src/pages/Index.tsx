
import { useUser } from "@/context/UserContext";
import { UserProvider } from "@/context/UserContext";
import { NavigationProvider } from "@/context/NavigationContext";
import OnboardingForm from "@/components/OnboardingForm";
import Layout from "@/components/Layout";

const IndexContent = () => {
  const { isOnboarded } = useUser();

  return isOnboarded ? <Layout /> : <OnboardingForm />;
};

const Index = () => {
  return (
    <UserProvider>
      <NavigationProvider>
        <IndexContent />
      </NavigationProvider>
    </UserProvider>
  );
};

export default Index;
