
import { Bell, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

type Reminder = {
  id: string;
  title: string;
  time: string;
  completed: boolean;
};

type RemindersListProps = {
  reminders: Reminder[];
  className?: string;
};

const RemindersList = ({ reminders, className }: RemindersListProps) => {
  const handleMarkComplete = (id: string) => {
    toast.success("Reminder marked as complete");
  };

  return (
    <div className={className}>
      {reminders.length > 0 ? (
        <div className="space-y-3">
          {reminders.map((reminder) => (
            <div
              key={reminder.id}
              className="flex items-start p-3 rounded-lg bg-white/40 hover:bg-white/60 transition-colors"
            >
              <div className="p-2 bg-brand-lightPurple rounded-full mr-3">
                <Bell className="h-4 w-4 text-brand-purple" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-sm">{reminder.title}</h4>
                <p className="text-xs text-gray-500">{reminder.time}</p>
              </div>
              {!reminder.completed && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-gray-400 hover:text-green-500"
                  onClick={() => handleMarkComplete(reminder.id)}
                >
                  <CheckCircle className="h-5 w-5" />
                </Button>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          <Bell className="h-10 w-10 text-gray-300 mx-auto mb-2" />
          <p className="text-gray-500">No reminders</p>
        </div>
      )}
    </div>
  );
};

export default RemindersList;
