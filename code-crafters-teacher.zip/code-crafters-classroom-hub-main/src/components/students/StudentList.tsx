
import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Search, Mail, MoreHorizontal, UserPlus, Calendar, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useNavigation } from "@/context/NavigationContext";

type Student = {
  id: string;
  name: string;
  email: string;
  joinedDate: string;
  status: "active" | "pending";
};

// We'll use empty initial students and manage them fully
const initialStudents: Student[] = [];

const StudentList = () => {
  const { addAlert } = useNavigation();
  const [students, setStudents] = useState<Student[]>(initialStudents);
  const [searchTerm, setSearchTerm] = useState("");
  const [newStudent, setNewStudent] = useState({ name: "", email: "" });
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  // Update local storage when students change
  useEffect(() => {
    localStorage.setItem('studentCount', students.length.toString());
    
    // Dispatch storage event to notify other components
    const event = new StorageEvent('storage', {
      key: 'studentCount',
      newValue: students.length.toString(),
    });
    window.dispatchEvent(event);
    
    // Send alert for new students
    if (students.length > 0 && students.length % 3 === 0) {
      addAlert({
        type: "success",
        message: `Milestone reached: ${students.length} students enrolled!`
      });
    }
  }, [students, addAlert]);
  
  const filteredStudents = students.filter(
    (student) =>
      student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.email.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const handleAddStudent = () => {
    if (!newStudent.name.trim() || !newStudent.email.trim()) {
      toast.error("Please fill in all fields");
      return;
    }
    
    if (!newStudent.email.includes('@') || !newStudent.email.includes('.')) {
      toast.error("Please enter a valid email address");
      return;
    }
    
    const newStudentObj: Student = {
      id: Date.now().toString(),
      name: newStudent.name,
      email: newStudent.email,
      joinedDate: new Date().toISOString().split("T")[0],
      status: "active",
    };
    
    setStudents([...students, newStudentObj]);
    setNewStudent({ name: "", email: "" });
    setIsDialogOpen(false);
    toast.success(`Student "${newStudent.name}" added successfully`);
  };

  const handleRemoveStudent = (id: string) => {
    const studentToRemove = students.find(student => student.id === id);
    if (!studentToRemove) return;
    
    setStudents(students.filter(student => student.id !== id));
    toast.info(`Removed ${studentToRemove.name} from your students`);
  };

  const handleSendEmail = (student: Student) => {
    toast.success(`Email sent to ${student.name} at ${student.email}`);
  };

  return (
    <Card className="p-4 glass-card hover-glow lg:col-span-2">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <h2 className="text-xl font-semibold text-white">Students</h2>
        
        <div className="flex w-full sm:w-auto gap-2">
          <div className="relative flex-1 sm:flex-none">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-300" size={16} />
            <Input
              placeholder="Search students..."
              className="pl-9 glass-input"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-brand-purple to-brand-neonBlue hover:opacity-90">
                <Plus size={16} className="mr-1" /> Add Student
              </Button>
            </DialogTrigger>
            <DialogContent className="glass border-white/10">
              <DialogHeader>
                <DialogTitle className="gradient-text">Add New Student</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-white">Name</Label>
                  <Input
                    id="name"
                    placeholder="Enter student name"
                    value={newStudent.name}
                    onChange={(e) =>
                      setNewStudent({ ...newStudent, name: e.target.value })
                    }
                    className="glass-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-white">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter student email"
                    value={newStudent.email}
                    onChange={(e) =>
                      setNewStudent({ ...newStudent, email: e.target.value })
                    }
                    className="glass-input"
                  />
                </div>
                <DialogFooter>
                  <Button
                    className="w-full bg-gradient-to-r from-brand-purple to-brand-neonBlue hover:opacity-90"
                    onClick={handleAddStudent}
                  >
                    Add Student
                  </Button>
                </DialogFooter>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      <div className="rounded-md border border-white/10 glass">
        <Table>
          <TableHeader className="bg-black/20">
            <TableRow className="border-white/10 hover:bg-transparent">
              <TableHead className="text-purple-300">Name</TableHead>
              <TableHead className="text-purple-300">Email</TableHead>
              <TableHead className="text-purple-300">Joined</TableHead>
              <TableHead className="text-purple-300">Status</TableHead>
              <TableHead className="w-24 text-purple-300"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredStudents.length > 0 ? (
              filteredStudents.map((student) => (
                <TableRow key={student.id} className="border-white/10 hover:bg-black/20">
                  <TableCell className="font-medium text-white">{student.name}</TableCell>
                  <TableCell className="text-gray-300">{student.email}</TableCell>
                  <TableCell className="text-gray-300">
                    {new Date(student.joinedDate).toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    <span
                      className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        student.status === "active"
                          ? "bg-green-900/50 text-green-300"
                          : "bg-amber-900/50 text-amber-300"
                      }`}
                    >
                      {student.status === "active" ? "Active" : "Pending"}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 hover:bg-white/10 text-purple-300"
                        title="Send Email"
                        onClick={() => handleSendEmail(student)}
                      >
                        <Mail size={16} />
                      </Button>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 hover:bg-white/10 text-purple-300"
                            title="More Options"
                          >
                            <MoreHorizontal size={16} />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="glass border-white/10 sm:max-w-md">
                          <DialogHeader>
                            <DialogTitle className="text-white">Student Options</DialogTitle>
                          </DialogHeader>
                          <div className="py-4">
                            <div className="flex flex-col gap-1 mb-4">
                              <h3 className="font-medium text-white">{student.name}</h3>
                              <p className="text-sm text-gray-300">{student.email}</p>
                            </div>
                            <div className="space-y-3">
                              <Button 
                                variant="outline" 
                                className="w-full justify-start glass-button text-purple-300"
                                onClick={() => handleSendEmail(student)}
                              >
                                <Mail size={16} className="mr-2" /> Send Email
                              </Button>
                              <Button 
                                variant="outline" 
                                className="w-full justify-start glass-button text-purple-300"
                              >
                                <Calendar size={16} className="mr-2" /> View Schedule
                              </Button>
                              <Button 
                                variant="outline" 
                                className="w-full justify-start glass-button text-red-300 hover:text-red-200 hover:bg-red-950/30"
                                onClick={() => {
                                  handleRemoveStudent(student.id);
                                  document.querySelector('[data-radix-popper-content-wrapper]')?.remove();
                                }}
                              >
                                <AlertCircle size={16} className="mr-2" /> Remove Student
                              </Button>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow className="border-white/10">
                <TableCell colSpan={5} className="text-center py-10 text-gray-400">
                  <div className="flex flex-col items-center">
                    <UserPlus size={30} className="mb-2 opacity-50" />
                    <p>No students found</p>
                    <p className="text-sm text-gray-500 mt-1">Add your first student to get started</p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="mt-4 glass-button text-purple-300"
                      onClick={() => setIsDialogOpen(true)}
                    >
                      <Plus size={14} className="mr-1" /> Add Student
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
};

export default StudentList;
