
import { CalendarClock } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

type Student = {
  id: string;
  name: string;
  avatarUrl?: string;
};

type UpcomingClassProps = {
  title: string;
  time: string;
  students: Student[];
  className?: string;
  onStartClass?: () => void;
  onViewDetails?: () => void;
};

const UpcomingClass = ({ 
  title, 
  time, 
  students, 
  className, 
  onStartClass, 
  onViewDetails 
}: UpcomingClassProps) => {
  const formattedTime = new Date(time).toLocaleTimeString([], { 
    hour: '2-digit', 
    minute: '2-digit'
  });
  
  const formattedDate = new Date(time).toLocaleDateString([], {
    month: 'short',
    day: 'numeric' 
  });
  
  // Only show up to 3 students, with a +X for any additional
  const displayStudents = students.slice(0, 3);
  const remainingCount = students.length - displayStudents.length;

  return (
    <Card className={`glass-card p-4 ${className}`}>
      <div className="flex items-start justify-between">
        <div>
          <h3 className="font-medium text-lg">{title}</h3>
          <div className="flex items-center text-sm text-gray-500 mt-1">
            <CalendarClock size={16} className="mr-1" />
            <span>{formattedDate}, {formattedTime}</span>
          </div>
        </div>
        <Badge variant="outline" className="bg-brand-lightPurple text-brand-purple border-none">
          Upcoming
        </Badge>
      </div>
      
      <div className="mt-4">
        <p className="text-sm text-gray-500 mb-2">Students</p>
        <div className="flex items-center">
          <div className="flex -space-x-2">
            {displayStudents.map(student => (
              <Avatar key={student.id} className="border-2 border-white h-8 w-8">
                <AvatarImage src={student.avatarUrl} alt={student.name} />
                <AvatarFallback className="bg-brand-purple text-white text-xs">
                  {student.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
            ))}
            {remainingCount > 0 && (
              <div className="h-8 w-8 rounded-full bg-gray-100 border-2 border-white flex items-center justify-center text-xs text-gray-600">
                +{remainingCount}
              </div>
            )}
          </div>
          <span className="ml-3 text-sm text-gray-500">{students.length} enrolled</span>
        </div>
      </div>
      
      <div className="mt-4 flex space-x-2">
        <Button 
          className="flex-1 bg-brand-purple hover:bg-brand-purple/90"
          size="sm"
          onClick={onStartClass}
        >
          Start Class
        </Button>
        <Button 
          variant="outline" 
          className="flex-1 border-brand-purple text-brand-purple hover:bg-brand-lightPurple hover:text-brand-purple"
          size="sm"
          onClick={onViewDetails}
        >
          View Details
        </Button>
      </div>
    </Card>
  );
};

export default UpcomingClass;
