
import { useNavigation, NavigationItem } from "../context/NavigationContext";
import Logo from "./Logo";
import { 
  LayoutDashboard, 
  Users, 
  Video, 
  BookOpen, 
  ClipboardList, 
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { cn } from "@/lib/utils";

const navigationItems = [
  {
    id: "dashboard" as NavigationItem,
    label: "Dashboard",
    icon: LayoutDashboard
  },
  {
    id: "classroom" as NavigationItem,
    label: "Classroom",
    icon: Users
  },
  {
    id: "live-lessons" as NavigationItem,
    label: "Live Lessons",
    icon: Video
  },
  {
    id: "recorded-lessons" as NavigationItem,
    label: "Recorded Lessons",
    icon: BookOpen
  },
  {
    id: "assignments" as NavigationItem,
    label: "Assignments",
    icon: ClipboardList
  }
];

const SidebarNavigation = () => {
  const { activeItem, setActiveItem, isSidebarCollapsed, toggleSidebar } = useNavigation();
  
  return (
    <div className={cn(
      "glass-sidebar h-screen flex flex-col transition-all duration-300 z-10",
      isSidebarCollapsed ? "w-20" : "w-64"
    )}>
      <div className="flex justify-between items-center">
        <Logo collapsed={isSidebarCollapsed} />
        <button 
          onClick={toggleSidebar} 
          className="p-2 hover:bg-white/10 rounded-full mr-2 transition-colors text-purple-300"
        >
          {isSidebarCollapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
        </button>
      </div>
      
      <nav className="flex-1 px-3 py-4">
        <ul className="space-y-2">
          {navigationItems.map((item) => (
            <li key={item.id}>
              <button
                onClick={() => setActiveItem(item.id)}
                className={cn(
                  "menu-item w-full transition-all duration-200",
                  activeItem === item.id ? "active" : "",
                  activeItem === item.id && !isSidebarCollapsed && "neon-glow-purple"
                )}
              >
                <item.icon size={20} className={activeItem === item.id ? "text-white" : "text-purple-300"} />
                {!isSidebarCollapsed && <span>{item.label}</span>}
              </button>
            </li>
          ))}
        </ul>
      </nav>
      
      <div className="p-4 border-t border-white/10">
        {!isSidebarCollapsed && (
          <div className="text-sm text-gray-400">
            Code Crafters &copy; {new Date().getFullYear()}
          </div>
        )}
      </div>
    </div>
  );
};

export default SidebarNavigation;
