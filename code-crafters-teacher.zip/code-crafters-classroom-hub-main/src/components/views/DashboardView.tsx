
import { useUser } from "@/context/UserContext";
import { useNavigation } from "@/context/NavigationContext";
import { useState, useEffect } from "react";
import StatCard from "../dashboard/StatCard";
import UpcomingClass from "../dashboard/UpcomingClass";
import Calendar from "../calendar/Calendar";
import StudentList from "../students/StudentList";
import RemindersList from "../reminders/RemindersList";
import { Users, BookOpen, Video, Clock, Plus, AlertTriangle, BarChart } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const DashboardView = () => {
  const { user } = useUser();
  const { addAlert, analytics, updateAnalytics } = useNavigation();
  const currentDate = new Date();
  const [isReminderDialogOpen, setIsReminderDialogOpen] = useState(false);
  const [reminderTitle, setReminderTitle] = useState("");
  const [reminderTime, setReminderTime] = useState("");
  const [studentCount, setStudentCount] = useState(0);
  const [assignmentCount, setAssignmentCount] = useState(0);

  const [upcomingClasses, setUpcomingClasses] = useState([
    {
      id: "1",
      title: `${user.subject} - Introduction`,
      time: new Date(currentDate.getTime() + 2 * 60 * 60 * 1000).toISOString(),
      students: [
        { id: "1", name: "Alex Johnson" },
        { id: "2", name: "Samantha Lee" },
        { id: "3", name: "Marcus Chen" },
        { id: "4", name: "Taylor Wong" },
      ],
    },
    {
      id: "2",
      title: `${user.subject} - Advanced Concepts`,
      time: new Date(currentDate.getTime() + 26 * 60 * 60 * 1000).toISOString(),
      students: [
        { id: "1", name: "Alex Johnson" },
        { id: "2", name: "Samantha Lee" },
      ],
    },
  ]);

  const [calendarEvents, setCalendarEvents] = useState([
    {
      id: "1",
      title: `${user.subject} - Introduction`,
      date: new Date(currentDate.getTime() + 2 * 60 * 60 * 1000),
      type: "class" as const,
    },
    {
      id: "2",
      title: `${user.subject} - Advanced Concepts`,
      date: new Date(currentDate.getTime() + 26 * 60 * 60 * 1000),
      type: "class" as const,
    },
    {
      id: "3",
      title: "Submit Quiz Results",
      date: new Date(currentDate.getTime() + 5 * 24 * 60 * 60 * 1000),
      type: "assignment" as const,
    },
  ]);

  const [reminders, setReminders] = useState([
    {
      id: "1",
      title: "Prepare materials for tomorrow's class",
      time: "Today, 4:00 PM",
      completed: false,
    },
    {
      id: "2",
      title: "Grade weekly assignments",
      time: "Tomorrow, 10:00 AM",
      completed: false,
    },
    {
      id: "3",
      title: "Team meeting with faculty",
      time: "Dec 20, 2:00 PM",
      completed: false,
    },
  ]);

  useEffect(() => {
    // Listen for student count updates from StudentList component
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'studentCount') {
        const count = parseInt(e.newValue || '0', 10);
        setStudentCount(count);
        
        // Update analytics with new student data
        if (count > 0) {
          const newAnalytics = {
            trendingStudents: [
              { 
                id: "1", 
                name: "Alex Johnson", 
                performance: "improving" as const 
              },
              { 
                id: "2", 
                name: "Samantha Lee", 
                performance: "stable" as const 
              }
            ],
            classPerformance: [
              { 
                classId: "1", 
                name: `${user.subject} - Introduction`, 
                averageScore: 85
              }
            ]
          };
          
          updateAnalytics(newAnalytics);
          
          if (count % 3 === 0) {
            addAlert({
              type: "info",
              message: "AI Analysis: New student enrollment pattern detected."
            });
          }
        }
      }
      
      if (e.key === 'assignmentCount') {
        setAssignmentCount(parseInt(e.newValue || '0', 10));
      }
    };
    
    window.addEventListener('storage', handleStorageChange);
    
    // Check initial values
    const initialStudentCount = parseInt(localStorage.getItem('studentCount') || '0', 10);
    setStudentCount(initialStudentCount);
    
    const initialAssignmentCount = parseInt(localStorage.getItem('assignmentCount') || '0', 10);
    setAssignmentCount(initialAssignmentCount);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [addAlert, updateAnalytics, user.subject]);

  const handleStartClass = (classId: string) => {
    const classItem = upcomingClasses.find(c => c.id === classId);
    if (!classItem) return;
    
    // Update calendar events
    const updatedEvents = [...calendarEvents];
    const eventIndex = updatedEvents.findIndex(e => e.id === classId);
    if (eventIndex >= 0) {
      updatedEvents[eventIndex] = {
        ...updatedEvents[eventIndex],
        title: `[LIVE] ${updatedEvents[eventIndex].title}`,
      };
      setCalendarEvents(updatedEvents);
    }
    
    toast.success(`Starting class: ${classItem.title}`);
    addAlert({
      type: "success",
      message: `Live class "${classItem.title}" started successfully`
    });
  };
  
  const handleViewClassDetails = (classId: string) => {
    const classItem = upcomingClasses.find(c => c.id === classId);
    if (!classItem) return;
    
    toast.info(`Viewing details for: ${classItem.title}`);
  };

  const handleAddReminder = () => {
    if (!reminderTitle.trim()) {
      toast.error("Please enter a reminder title");
      return;
    }
    
    if (!reminderTime) {
      toast.error("Please select a time for the reminder");
      return;
    }
    
    const newReminder = {
      id: Date.now().toString(),
      title: reminderTitle,
      time: reminderTime,
      completed: false,
    };
    
    setReminders([...reminders, newReminder]);
    setReminderTitle("");
    setReminderTime("");
    setIsReminderDialogOpen(false);
    toast.success("Reminder added successfully");
  };

  // For the schedule dialog
  const [isScheduleDialogOpen, setIsScheduleDialogOpen] = useState(false);
  const [newClass, setNewClass] = useState({
    title: "",
    date: "",
    time: "",
    duration: "60",
    description: "",
  });

  const handleScheduleClass = () => {
    if (!newClass.title || !newClass.date || !newClass.time) {
      toast.error("Please fill in all required fields");
      return;
    }
    
    const scheduledDateTime = new Date(`${newClass.date}T${newClass.time}`);
    
    // Create new class
    const newClassObj = {
      id: Date.now().toString(),
      title: newClass.title,
      time: scheduledDateTime.toISOString(),
      students: [],
    };
    
    // Create new calendar event
    const newEvent = {
      id: newClassObj.id,
      title: newClass.title,
      date: scheduledDateTime,
      type: "class" as const,
    };
    
    setUpcomingClasses([...upcomingClasses, newClassObj]);
    setCalendarEvents([...calendarEvents, newEvent]);
    
    setNewClass({
      title: "",
      date: "",
      time: "",
      duration: "60",
      description: "",
    });
    
    setIsScheduleDialogOpen(false);
    toast.success("Class scheduled successfully");
  };

  return (
    <div className="p-6 space-y-6">
      <div className="animate-fade-in">
        <h1 className="text-2xl font-bold mb-2 gradient-text">
          Welcome back, {user.name}!
        </h1>
        <p className="text-gray-400">
          Here's what's happening with your {user.subject} classes today.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 animate-slide-in">
        <StatCard
          title="Total Students"
          value={studentCount.toString()}
          icon={Users}
          trend={{ value: studentCount > 0 ? Math.floor(studentCount / 2) : 0, isPositive: true }}
          className="glass-card hover-scale"
        />
        <StatCard
          title="Assignments"
          value={assignmentCount.toString()}
          icon={BookOpen}
          description={assignmentCount > 0 ? "3 need grading" : "No assignments yet"}
          className="glass-card hover-scale"
        />
        <StatCard
          title="Live Sessions"
          value={upcomingClasses.length.toString()}
          icon={Video}
          description={`${Math.min(upcomingClasses.length, 4)} this week`}
          className="glass-card hover-scale"
        />
        <StatCard
          title="Teaching Hours"
          value={(upcomingClasses.length * 2).toString()}
          icon={Clock}
          trend={{ value: 2, isPositive: true }}
          className="glass-card hover-scale"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 p-4 glass-card hover-glow">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-semibold text-lg text-white">Upcoming Classes</h2>
            <Dialog open={isScheduleDialogOpen} onOpenChange={setIsScheduleDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="glass-button text-white">
                  <Plus size={14} className="mr-1" /> Schedule Class
                </Button>
              </DialogTrigger>
              <DialogContent className="glass border-white/10">
                <DialogHeader>
                  <DialogTitle className="gradient-text">Schedule New Class</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="class-title" className="text-white">Class Title</Label>
                    <Input 
                      id="class-title" 
                      placeholder="Enter class title"
                      value={newClass.title}
                      onChange={(e) => setNewClass(prev => ({ ...prev, title: e.target.value }))}
                      className="glass-input"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="class-date" className="text-white">Date</Label>
                      <Input 
                        id="class-date" 
                        type="date"
                        value={newClass.date}
                        onChange={(e) => setNewClass(prev => ({ ...prev, date: e.target.value }))}
                        className="glass-input"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="class-time" className="text-white">Time</Label>
                      <Input 
                        id="class-time" 
                        type="time"
                        value={newClass.time}
                        onChange={(e) => setNewClass(prev => ({ ...prev, time: e.target.value }))}
                        className="glass-input"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="class-duration" className="text-white">Duration (minutes)</Label>
                    <Input 
                      id="class-duration" 
                      type="number"
                      value={newClass.duration}
                      onChange={(e) => setNewClass(prev => ({ ...prev, duration: e.target.value }))}
                      className="glass-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="class-description" className="text-white">Description</Label>
                    <Textarea 
                      id="class-description" 
                      placeholder="Enter class description"
                      value={newClass.description}
                      onChange={(e) => setNewClass(prev => ({ ...prev, description: e.target.value }))}
                      className="glass-input"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button 
                    className="w-full bg-gradient-to-r from-brand-purple to-brand-neonBlue" 
                    onClick={handleScheduleClass}
                  >
                    Schedule Class
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          <div className="space-y-4">
            {upcomingClasses.length > 0 ? (
              upcomingClasses.map((classItem) => (
                <UpcomingClass
                  key={classItem.id}
                  title={classItem.title}
                  time={classItem.time}
                  students={classItem.students}
                  onStartClass={() => handleStartClass(classItem.id)}
                  onViewDetails={() => handleViewClassDetails(classItem.id)}
                  className="glass-card"
                />
              ))
            ) : (
              <div className="text-center py-10 text-gray-400">
                <Video size={40} className="mx-auto mb-3 opacity-50" />
                <p>No upcoming classes scheduled</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="mt-4 glass-button text-purple-300"
                  onClick={() => setIsScheduleDialogOpen(true)}
                >
                  <Plus size={14} className="mr-1" /> Schedule Your First Class
                </Button>
              </div>
            )}
          </div>
        </Card>

        <Calendar events={calendarEvents} className="glass-card" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <StudentList />
        
        <div className="lg:col-span-1 space-y-5">
          <Card className="p-4 glass-card">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-lg text-white">Reminders</h2>
              <Dialog open={isReminderDialogOpen} onOpenChange={setIsReminderDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="glass-button text-purple-300">
                    Add Reminder
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md glass border-white/10">
                  <DialogHeader>
                    <DialogTitle className="gradient-text">Add New Reminder</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="reminder-title" className="text-white">Reminder Title</Label>
                      <Input 
                        id="reminder-title" 
                        placeholder="Enter reminder title"
                        value={reminderTitle}
                        onChange={(e) => setReminderTitle(e.target.value)}
                        className="glass-input"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="reminder-time" className="text-white">Time & Date</Label>
                      <Input 
                        id="reminder-time" 
                        placeholder="e.g., Tomorrow, 10:00 AM"
                        value={reminderTime}
                        onChange={(e) => setReminderTime(e.target.value)}
                        className="glass-input"
                      />
                    </div>
                    <Button 
                      className="w-full bg-gradient-to-r from-brand-purple to-brand-neonBlue" 
                      onClick={handleAddReminder}
                    >
                      Add Reminder
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
            <RemindersList reminders={reminders} />
          </Card>
          
          {analytics.trendingStudents.length > 0 && (
            <Card className="p-4 glass-card">
              <div className="flex items-center mb-4">
                <BarChart size={18} className="text-purple-300 mr-2" />
                <h2 className="font-semibold text-lg text-white">Smart Analytics</h2>
              </div>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <h3 className="text-sm font-medium text-purple-300">Trending Student Performance</h3>
                  <div className="space-y-2">
                    {analytics.trendingStudents.map(student => (
                      <div key={student.id} className="flex items-center justify-between p-2 glass">
                        <span className="text-sm text-white">{student.name}</span>
                        <Badge 
                          variant={
                            student.performance === "improving" ? "success" : 
                            student.performance === "declining" ? "destructive" : 
                            "secondary"
                          }
                        >
                          {student.performance === "improving" ? "Improving" : 
                           student.performance === "declining" ? "Needs Help" : 
                           "Stable"}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
                
                {analytics.classPerformance.length > 0 && (
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium text-purple-300">Class Performance</h3>
                    <div className="space-y-2">
                      {analytics.classPerformance.map(classPerf => (
                        <div key={classPerf.classId} className="p-2 glass">
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-sm text-white truncate">{classPerf.name}</span>
                            <span className="text-xs text-gray-300">{classPerf.averageScore}%</span>
                          </div>
                          <div className="w-full h-2 bg-black/30 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-gradient-to-r from-brand-purple to-brand-neonBlue"
                              style={{ width: `${classPerf.averageScore}%` }}
                            ></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <div className="flex items-center gap-2 text-xs text-gray-400 mt-4">
                  <AlertTriangle size={12} />
                  <span>AI-powered insights based on your classroom data</span>
                </div>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default DashboardView;
