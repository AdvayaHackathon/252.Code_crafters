
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Video, 
  Calendar, 
  Users, 
  Plus,
  Clock,
  PlayCircle,
  Link,
  Share2, 
  MessageSquare,
  Settings,
  Camera,
  Mic,
  MicOff,
  VideoOff
} from "lucide-react";
import { useUser } from "@/context/UserContext";
import { useNavigation } from "@/context/NavigationContext";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

type LiveSession = {
  id: string;
  title: string;
  scheduledFor: Date;
  duration: number;
  description: string;
  studentCount: number;
  status: "upcoming" | "live" | "completed";
};

const LiveLessonsView = () => {
  const { user } = useUser();
  const { addAlert } = useNavigation();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLiveDialogOpen, setIsLiveDialogOpen] = useState(false);
  const [activeLiveSessionId, setActiveLiveSessionId] = useState<string | null>(null);
  const [newSession, setNewSession] = useState({
    title: "",
    date: "",
    time: "",
    duration: "60",
    description: "",
    classroom: "1"
  });
  
  const [sessions, setSessions] = useState<LiveSession[]>([]);

  const handleCreateSession = () => {
    if (!newSession.title || !newSession.date || !newSession.time) {
      toast.error("Please fill in all required fields");
      return;
    }
    
    const scheduledDateTime = new Date(`${newSession.date}T${newSession.time}`);
    
    const session: LiveSession = {
      id: Date.now().toString(),
      title: newSession.title,
      scheduledFor: scheduledDateTime,
      duration: parseInt(newSession.duration),
      description: newSession.description || "No description provided",
      studentCount: 0,
      status: "upcoming",
    };
    
    setSessions([...sessions, session]);
    setNewSession({
      title: "",
      date: "",
      time: "",
      duration: "60",
      description: "",
      classroom: "1"
    });
    
    setIsDialogOpen(false);
    toast.success("Live session scheduled");
    
    // Add a calendar event
    const event = new StorageEvent('storage', {
      key: 'calendarEvent',
      newValue: JSON.stringify({
        id: session.id,
        title: session.title,
        date: session.scheduledFor,
        type: "class"
      }),
    });
    window.dispatchEvent(event);
    
    addAlert({
      type: "info",
      message: `New session "${session.title}" scheduled for ${scheduledDateTime.toLocaleDateString()}`
    });
  };

  const handleStartSession = (id: string) => {
    setSessions(
      sessions.map((session) =>
        session.id === id ? { ...session, status: "live" as const } : session
      )
    );
    setActiveLiveSessionId(id);
    setIsLiveDialogOpen(true);
    toast.success(`Session "${sessions.find(s => s.id === id)?.title}" started`);
    addAlert({
      type: "success",
      message: `Live session "${sessions.find(s => s.id === id)?.title}" has started`
    });
  };

  const handleJoinSession = (id: string) => {
    setActiveLiveSessionId(id);
    setIsLiveDialogOpen(true);
    toast.success(`Joining session: ${sessions.find(s => s.id === id)?.title}`);
  };

  const handleViewRecording = (id: string) => {
    toast.info(`Viewing recording for: ${sessions.find(s => s.id === id)?.title}`);
  };

  const handleCopyLink = (id: string) => {
    toast.success("Session link copied to clipboard");
  };

  const handleEndSession = (id: string) => {
    setSessions(
      sessions.map((session) =>
        session.id === id ? { ...session, status: "completed" as const } : session
      )
    );
    setIsLiveDialogOpen(false);
    toast.success(`Session "${sessions.find(s => s.id === id)?.title}" ended`);
  };

  const formatSessionTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ", " + 
           date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  const getActiveSession = () => {
    return sessions.find(s => s.id === activeLiveSessionId);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold mb-1 gradient-text">Live Lessons</h1>
          <p className="text-gray-400">
            Create and manage real-time virtual classroom sessions
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-brand-purple to-brand-neonBlue hover:opacity-90 sm:self-start">
              <Plus size={16} className="mr-1" /> Schedule Session
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md glass border-white/10">
            <DialogHeader>
              <DialogTitle className="gradient-text">Schedule Live Session</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="title" className="text-white">Session Title</Label>
                <Input 
                  id="title" 
                  placeholder="Enter session title"
                  value={newSession.title}
                  onChange={(e) => setNewSession(prev => ({ ...prev, title: e.target.value }))}
                  className="glass-input"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="date" className="text-white">Date</Label>
                  <Input 
                    id="date" 
                    type="date"
                    value={newSession.date}
                    onChange={(e) => setNewSession(prev => ({ ...prev, date: e.target.value }))}
                    className="glass-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="time" className="text-white">Time</Label>
                  <Input 
                    id="time" 
                    type="time"
                    value={newSession.time}
                    onChange={(e) => setNewSession(prev => ({ ...prev, time: e.target.value }))}
                    className="glass-input"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="duration" className="text-white">Duration</Label>
                <Select 
                  defaultValue={newSession.duration}
                  onValueChange={(value) => setNewSession(prev => ({ ...prev, duration: value }))}
                >
                  <SelectTrigger className="glass-input">
                    <SelectValue placeholder="Select duration" />
                  </SelectTrigger>
                  <SelectContent className="glass border-white/10">
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="45">45 minutes</SelectItem>
                    <SelectItem value="60">1 hour</SelectItem>
                    <SelectItem value="90">1 hour 30 minutes</SelectItem>
                    <SelectItem value="120">2 hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="description" className="text-white">Description</Label>
                <Textarea 
                  id="description" 
                  placeholder="Enter session description"
                  value={newSession.description}
                  onChange={(e) => setNewSession(prev => ({ ...prev, description: e.target.value }))}
                  className="glass-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="classroom" className="text-white">Classroom</Label>
                <Select 
                  defaultValue={newSession.classroom}
                  onValueChange={(value) => setNewSession(prev => ({ ...prev, classroom: value }))}
                >
                  <SelectTrigger className="glass-input">
                    <SelectValue placeholder="Select classroom" />
                  </SelectTrigger>
                  <SelectContent className="glass border-white/10">
                    <SelectItem value="1">{user.subject} - Class A</SelectItem>
                    <SelectItem value="2">{user.subject} - Class B</SelectItem>
                    <SelectItem value="3">{user.subject} - Advanced</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <DialogFooter>
                <Button 
                  className="w-full bg-gradient-to-r from-brand-purple to-brand-neonBlue" 
                  onClick={handleCreateSession}
                >
                  Schedule Session
                </Button>
              </DialogFooter>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {sessions.map((session) => (
          <Card 
            key={session.id} 
            className={cn(
              "glass-card p-5 transition-all duration-300 hover-glow",
              session.status === "live" && "border-green-500/50 neon-glow-blue"
            )}
          >
            <div className="flex justify-between items-start mb-4">
              <div className="flex-1">
                <h3 className="font-medium text-white">{session.title}</h3>
                <div className="flex items-center text-sm text-gray-400 mt-1">
                  <Calendar size={15} className="mr-1 text-purple-300" />
                  <span>{formatSessionTime(session.scheduledFor)}</span>
                </div>
              </div>
              {session.status === "live" && (
                <Badge variant="gradient" className="animate-pulse-glow">
                  Live Now
                </Badge>
              )}
              {session.status === "upcoming" && (
                <Badge variant="secondary" className="bg-blue-900/50 text-blue-300 border-blue-500/30">
                  Upcoming
                </Badge>
              )}
              {session.status === "completed" && (
                <Badge variant="secondary" className="bg-gray-900/50 text-gray-300 border-gray-500/30">
                  Completed
                </Badge>
              )}
            </div>
            
            <p className="text-sm text-gray-300 mt-2 mb-4 line-clamp-2">{session.description}</p>
            
            <div className="flex space-x-4 mb-4">
              <div className="flex items-center text-sm text-gray-400">
                <Clock size={15} className="mr-1 text-purple-300" />
                <span>{session.duration} min</span>
              </div>
              <div className="flex items-center text-sm text-gray-400">
                <Users size={15} className="mr-1 text-purple-300" />
                <span>{session.studentCount} students</span>
              </div>
            </div>
            
            {session.status === "upcoming" ? (
              <div className="flex space-x-2 mt-4">
                <Button 
                  variant="outline" 
                  className="flex-1 glass-button text-purple-300"
                  onClick={() => handleCopyLink(session.id)}
                >
                  <Share2 size={15} className="mr-1" /> Share
                </Button>
                <Button 
                  className="flex-1 bg-gradient-to-r from-brand-purple to-brand-neonBlue hover:opacity-90"
                  onClick={() => handleStartSession(session.id)}
                >
                  <PlayCircle size={15} className="mr-1" /> Start
                </Button>
              </div>
            ) : session.status === "live" ? (
              <div className="flex space-x-2 mt-4">
                <Button 
                  variant="outline" 
                  className="flex-1 glass-button text-purple-300"
                  onClick={() => handleCopyLink(session.id)}
                >
                  <Link size={15} className="mr-1" /> Share
                </Button>
                <Button 
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  onClick={() => handleJoinSession(session.id)}
                >
                  <Video size={15} className="mr-1" /> Join
                </Button>
              </div>
            ) : (
              <div className="mt-4">
                <Button 
                  variant="outline" 
                  className="w-full glass-button text-purple-300"
                  onClick={() => handleViewRecording(session.id)}
                >
                  <PlayCircle size={15} className="mr-1" /> View Recording
                </Button>
              </div>
            )}
          </Card>
        ))}
        
        <Card 
          className="glass-card p-5 border-dashed border-white/10 hover-scale transition-colors cursor-pointer flex flex-col items-center justify-center min-h-[200px]" 
          onClick={() => setIsDialogOpen(true)}
        >
          <div className="p-4 rounded-full bg-accent/20 mb-3 animate-pulse-glow">
            <Plus size={24} className="text-purple-300" />
          </div>
          <h3 className="font-medium mb-2 text-white">Schedule Session</h3>
          <p className="text-sm text-gray-400 text-center">
            Create a new live teaching session
          </p>
        </Card>
      </div>
      
      {/* Live Session Interface */}
      <Dialog open={isLiveDialogOpen} onOpenChange={setIsLiveDialogOpen}>
        <DialogContent className="max-w-4xl glass border-white/10">
          <DialogHeader>
            <DialogTitle className="gradient-text">
              {getActiveSession()?.status === "live" ? "Live Session" : "Join Session"}
            </DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            <h2 className="text-xl font-medium mb-2 text-white">{getActiveSession()?.title}</h2>
            <Badge 
              variant={getActiveSession()?.status === "live" ? "gradient" : "secondary"} 
              className={getActiveSession()?.status === "live" ? "animate-pulse-glow" : ""}
            >
              {getActiveSession()?.status === "live" ? "Live" : "Joining"}
            </Badge>

            <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <div className="aspect-video bg-black/50 rounded-md flex items-center justify-center mb-4 relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 to-blue-900/20"></div>
                  <Video size={48} className="text-gray-600" />
                  <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex items-center space-x-2">
                    <Button 
                      variant="outline" 
                      size="icon" 
                      className="h-10 w-10 rounded-full glass-button text-white hover:bg-white/20"
                    >
                      <Mic size={18} />
                    </Button>
                    <Button 
                      variant="outline" 
                      size="icon" 
                      className="h-10 w-10 rounded-full glass-button text-white hover:bg-white/20"
                    >
                      <Camera size={18} />
                    </Button>
                    <Button 
                      className="h-10 px-4 rounded-full bg-red-600 hover:bg-red-700 text-white"
                      onClick={() => getActiveSession()?.id && handleEndSession(getActiveSession()?.id || "")}
                    >
                      End Session
                    </Button>
                  </div>
                </div>
                
                <div className="glass-card p-4">
                  <h3 className="text-sm font-medium text-purple-300 mb-3">In-Class Chat</h3>
                  <div className="h-40 overflow-y-auto mb-4 p-2 bg-black/20 rounded">
                    <div className="space-y-3">
                      <div className="flex gap-2">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
                          <span className="text-white text-sm">AJ</span>
                        </div>
                        <div className="bg-black/20 p-2 rounded-md max-w-[80%]">
                          <p className="text-sm text-white">Is the assignment due tomorrow?</p>
                          <p className="text-xs text-gray-400 mt-1">10:45</p>
                        </div>
                      </div>
                      
                      <div className="flex gap-2 justify-end">
                        <div className="bg-accent/20 p-2 rounded-md max-w-[80%]">
                          <p className="text-sm text-white">Yes, please submit it by 5pm.</p>
                          <p className="text-xs text-gray-400 mt-1">10:46</p>
                        </div>
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-green-500 to-teal-500 flex items-center justify-center">
                          <span className="text-white text-sm">Y</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Input 
                      placeholder="Type your message..." 
                      className="glass-input"
                    />
                    <Button 
                      variant="outline" 
                      className="glass-button text-purple-300"
                    >
                      <MessageSquare size={16} className="mr-1" /> Send
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <Card className="glass-card p-4">
                  <h3 className="text-sm font-medium text-purple-300 mb-3">Session Info</h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-sm">
                      <Clock className="text-purple-300" size={16} />
                      <span className="text-white">{getActiveSession()?.duration} minutes</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Calendar className="text-purple-300" size={16} />
                      <span className="text-white">{getActiveSession()?.scheduledFor.toLocaleDateString()}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Users className="text-purple-300" size={16} />
                      <span className="text-white">
                        {getActiveSession()?.studentCount || 0} students
                      </span>
                    </div>
                  </div>
                </Card>
                
                <Card className="glass-card p-4">
                  <h3 className="text-sm font-medium text-purple-300 mb-3">Participants (3)</h3>
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    <div className="flex items-center justify-between p-2 bg-black/20 rounded">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-purple-500 flex items-center justify-center">
                          <span className="text-white text-xs">Y</span>
                        </div>
                        <span className="text-sm text-white">You (Host)</span>
                      </div>
                      <div className="flex items-center">
                        <Mic size={14} className="text-green-400" />
                      </div>
                    </div>
                    <div className="flex items-center justify-between p-2 hover:bg-black/10 rounded">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-blue-500 flex items-center justify-center">
                          <span className="text-white text-xs">A</span>
                        </div>
                        <span className="text-sm text-gray-300">Alex Johnson</span>
                      </div>
                      <div className="flex items-center">
                        <MicOff size={14} className="text-gray-500" />
                      </div>
                    </div>
                    <div className="flex items-center justify-between p-2 hover:bg-black/10 rounded">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center">
                          <span className="text-white text-xs">S</span>
                        </div>
                        <span className="text-sm text-gray-300">Samantha Lee</span>
                      </div>
                      <div className="flex items-center">
                        <VideoOff size={14} className="text-gray-500" />
                      </div>
                    </div>
                  </div>
                </Card>
                
                <Card className="glass-card p-4">
                  <h3 className="text-sm font-medium text-purple-300 mb-3">Controls</h3>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start glass-button text-purple-300">
                      <Share2 size={15} className="mr-2" /> Share Screen
                    </Button>
                    <Button variant="outline" className="w-full justify-start glass-button text-purple-300">
                      <Settings size={15} className="mr-2" /> Session Settings
                    </Button>
                    <Button variant="destructive" className="w-full">
                      End Session
                    </Button>
                  </div>
                </Card>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default LiveLessonsView;
