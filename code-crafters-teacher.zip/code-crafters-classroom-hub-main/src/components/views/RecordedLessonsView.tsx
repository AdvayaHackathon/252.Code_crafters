
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { useUser } from "@/context/UserContext";

import VideoUploader from "../video/VideoUploader";
import VideoCard from "../video/VideoCard";
import EmptyVideoState from "../video/EmptyVideoState";
import FilterControls from "../video/FilterControls";
import VideoPlayer from "../video/VideoPlayer";
import { VideoLesson } from "@/types/video";

const RecordedLessonsView = () => {
  const { user } = useUser();
  const [searchTerm, setSearchTerm] = useState("");
  const [activeFilter, setActiveFilter] = useState<string | null>(null);
  const [currentPlayingId, setCurrentPlayingId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("videos");
  
  const [videos, setVideos] = useState<VideoLesson[]>([]);

  const handleUploadComplete = (videoData: { name: string; size: number; url: string }) => {
    const newVideo: VideoLesson = {
      id: Date.now().toString(),
      title: videoData.name.split('.')[0],
      duration: "Processing...",
      uploadDate: new Date().toISOString().split('T')[0],
      views: 0,
      topic: "Uncategorized",
      videoUrl: videoData.url
    };
    
    // Process the video to calculate actual duration
    const tempVideo = document.createElement('video');
    tempVideo.src = videoData.url;
    tempVideo.onloadedmetadata = () => {
      const minutes = Math.floor(tempVideo.duration / 60);
      const seconds = Math.floor(tempVideo.duration % 60);
      const formattedDuration = `${minutes}:${seconds.toString().padStart(2, '0')}`;
      
      setVideos(prevVideos => 
        prevVideos.map(video => 
          video.id === newVideo.id 
            ? { ...video, duration: formattedDuration } 
            : video
        )
      );
    };
    
    setVideos([...videos, newVideo]);
    toast.success(`Video "${newVideo.title}" uploaded successfully`);
  };

  const handlePlayVideo = (videoId: string) => {
    const video = videos.find(v => v.id === videoId);
    if (!video || !video.videoUrl) {
      toast.error("Video source not available");
      return;
    }
    
    setCurrentPlayingId(videoId);
    
    // Update views count
    setVideos(videos.map(v => v.id === videoId ? { ...v, views: v.views + 1 } : v));
  };
  
  const handleEditVideo = (videoId: string) => {
    toast.info(`Editing ${videos.find(v => v.id === videoId)?.title}`);
  };

  // Filter videos by topic
  const filteredVideos = videos.filter(video => {
    const matchesSearch = video.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = !activeFilter || video.topic === activeFilter;
    return matchesSearch && matchesFilter;
  });

  // Get unique topics for filtering
  const topics = [...new Set(videos.map(video => video.topic))];
  
  // Get the currently playing video
  const currentVideo = videos.find(v => v.id === currentPlayingId) || null;

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1 gradient-text">Recorded Lessons</h1>
        <p className="text-gray-400">
          Upload, manage, and share your recorded video lectures
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4 glass-card">
          <TabsTrigger value="videos" className="data-[state=active]:text-white data-[state=active]:bg-accent/50">My Videos</TabsTrigger>
          <TabsTrigger value="upload" className="data-[state=active]:text-white data-[state=active]:bg-accent/50">Upload Video</TabsTrigger>
        </TabsList>
        
        <TabsContent value="videos">
          <FilterControls 
            searchTerm={searchTerm}
            onSearchChange={setSearchTerm}
            activeFilter={activeFilter}
            onFilterChange={setActiveFilter}
            topics={topics}
          />

          {videos.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredVideos.map((video) => (
                <VideoCard 
                  key={video.id}
                  video={video}
                  onPlay={handlePlayVideo}
                  onEdit={handleEditVideo}
                />
              ))}
            </div>
          ) : (
            <EmptyVideoState onUpload={() => setActiveTab("upload")} />
          )}
        </TabsContent>
        
        <TabsContent value="upload">
          <Card className="glass-card p-6">
            <h2 className="font-semibold text-lg mb-4 text-white">Upload New Video</h2>
            <VideoUploader onUploadComplete={handleUploadComplete} />
          </Card>
        </TabsContent>
      </Tabs>
      
      <VideoPlayer 
        isOpen={currentPlayingId !== null}
        onClose={() => setCurrentPlayingId(null)}
        video={currentVideo}
      />
    </div>
  );
};

export default RecordedLessonsView;
