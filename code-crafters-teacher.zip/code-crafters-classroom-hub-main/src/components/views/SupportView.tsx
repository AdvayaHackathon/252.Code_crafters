
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  HelpCircle,
  BookOpen,
  BarChart3,
  Video,
  Mail,
  MessageSquare,
  FileText,
  ExternalLink,
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";

const SupportView = () => {
  const storageUsage = 68; // Percentage used

  const handleContactSupport = () => {
    toast.info("Contact support form would open here");
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold mb-1">Help & Support</h1>
        <p className="text-gray-600">
          Get help with your Code Crafters account and tools
        </p>
      </div>

      <Tabs defaultValue="help">
        <TabsList className="mb-6">
          <TabsTrigger value="help">Help Center</TabsTrigger>
          <TabsTrigger value="system">System Status</TabsTrigger>
          <TabsTrigger value="storage">Storage</TabsTrigger>
        </TabsList>

        <TabsContent value="help">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card className="p-5 hover:shadow-md transition-shadow">
              <div className="p-3 bg-brand-lightPurple rounded-lg w-12 h-12 flex items-center justify-center mb-4">
                <Video className="text-brand-purple" size={24} />
              </div>
              <h3 className="font-medium mb-2">Video Tutorials</h3>
              <p className="text-sm text-gray-500 mb-4">
                Step-by-step guides to help you master the platform features
              </p>
              <Button variant="outline" className="w-full text-gray-600">
                Watch Tutorials
              </Button>
            </Card>

            <Card className="p-5 hover:shadow-md transition-shadow">
              <div className="p-3 bg-brand-lightPurple rounded-lg w-12 h-12 flex items-center justify-center mb-4">
                <BookOpen className="text-brand-purple" size={24} />
              </div>
              <h3 className="font-medium mb-2">Documentation</h3>
              <p className="text-sm text-gray-500 mb-4">
                Comprehensive guides and reference materials
              </p>
              <Button variant="outline" className="w-full text-gray-600">
                Read Docs
              </Button>
            </Card>

            <Card className="p-5 hover:shadow-md transition-shadow">
              <div className="p-3 bg-brand-lightPurple rounded-lg w-12 h-12 flex items-center justify-center mb-4">
                <MessageSquare className="text-brand-purple" size={24} />
              </div>
              <h3 className="font-medium mb-2">Community Forum</h3>
              <p className="text-sm text-gray-500 mb-4">
                Connect with other teachers and share best practices
              </p>
              <Button variant="outline" className="w-full text-gray-600">
                Visit Forum
              </Button>
            </Card>

            <Card className="p-5 hover:shadow-md transition-shadow">
              <div className="p-3 bg-brand-lightPurple rounded-lg w-12 h-12 flex items-center justify-center mb-4">
                <FileText className="text-brand-purple" size={24} />
              </div>
              <h3 className="font-medium mb-2">FAQ</h3>
              <p className="text-sm text-gray-500 mb-4">
                Quick answers to the most common questions
              </p>
              <Button variant="outline" className="w-full text-gray-600">
                Read FAQ
              </Button>
            </Card>

            <Card className="p-5 hover:shadow-md transition-shadow">
              <div className="p-3 bg-brand-lightPurple rounded-lg w-12 h-12 flex items-center justify-center mb-4">
                <Mail className="text-brand-purple" size={24} />
              </div>
              <h3 className="font-medium mb-2">Contact Support</h3>
              <p className="text-sm text-gray-500 mb-4">
                Get personalized help from our support team
              </p>
              <Button variant="outline" className="w-full text-gray-600" onClick={handleContactSupport}>
                Contact Us
              </Button>
            </Card>

            <Card className="p-5 hover:shadow-md transition-shadow">
              <div className="p-3 bg-brand-lightPurple rounded-lg w-12 h-12 flex items-center justify-center mb-4">
                <BarChart3 className="text-brand-purple" size={24} />
              </div>
              <h3 className="font-medium mb-2">Webinars</h3>
              <p className="text-sm text-gray-500 mb-4">
                Join our upcoming training sessions and webinars
              </p>
              <Button variant="outline" className="w-full text-gray-600">
                View Schedule
              </Button>
            </Card>
          </div>

          <Card className="mt-6 p-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div>
                <h3 className="text-lg font-semibold mb-2">Need additional help?</h3>
                <p className="text-gray-600 mb-4 md:mb-0">
                  Our support team is available Monday-Friday, 9am-5pm. We typically respond within 24 hours.
                </p>
              </div>
              <Button 
                className="bg-brand-purple hover:bg-brand-purple/90 whitespace-nowrap"
                onClick={handleContactSupport}
              >
                <Mail size={16} className="mr-2" />
                Contact Support
              </Button>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="system">
          <Card className="p-6 mb-6">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <h3 className="font-semibold">All Systems Operational</h3>
            </div>
            
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Video Streaming</span>
                  <span className="text-green-500">Operational</span>
                </div>
                <Progress value={100} className="h-2 bg-gray-100" />
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Live Lessons Platform</span>
                  <span className="text-green-500">Operational</span>
                </div>
                <Progress value={100} className="h-2 bg-gray-100" />
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Assignment Uploads</span>
                  <span className="text-green-500">Operational</span>
                </div>
                <Progress value={100} className="h-2 bg-gray-100" />
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Student Dashboard</span>
                  <span className="text-green-500">Operational</span>
                </div>
                <Progress value={100} className="h-2 bg-gray-100" />
              </div>
            </div>
            
            <div className="mt-6 pt-4 border-t border-gray-100">
              <a 
                href="#" 
                className="flex items-center text-sm text-brand-purple hover:underline"
                onClick={(e) => {
                  e.preventDefault();
                  toast.info("System status page would open here");
                }}
              >
                View detailed system status <ExternalLink size={14} className="ml-1" />
              </a>
            </div>
          </Card>
          
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Scheduled Maintenance</h3>
            <div className="space-y-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">Platform Updates</span>
                  <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Upcoming</span>
                </div>
                <p className="text-sm text-gray-500 mb-2">
                  Scheduled maintenance to improve platform performance and add new features.
                </p>
                <p className="text-xs text-gray-400">December 24, 2023 (2:00 AM - 4:00 AM EST)</p>
              </div>
              
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">Database Optimization</span>
                  <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">Completed</span>
                </div>
                <p className="text-sm text-gray-500 mb-2">
                  Optimization of database for improved performance and reliability.
                </p>
                <p className="text-xs text-gray-400">December 10, 2023</p>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="storage">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2 p-6">
              <h3 className="font-semibold mb-6">Storage Usage</h3>
              
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Total Storage (50GB)</span>
                    <span>{storageUsage}% used</span>
                  </div>
                  <Progress value={storageUsage} className="h-3 bg-gray-100" />
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">Video Files</span>
                      <span className="text-xs bg-brand-lightPurple text-brand-purple px-2 py-1 rounded-full">24.5 GB</span>
                    </div>
                    <Progress value={49} className="h-2 bg-gray-100" />
                  </div>
                  
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">Documents</span>
                      <span className="text-xs bg-brand-lightPurple text-brand-purple px-2 py-1 rounded-full">8.3 GB</span>
                    </div>
                    <Progress value={16.6} className="h-2 bg-gray-100" />
                  </div>
                  
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">Other Files</span>
                      <span className="text-xs bg-brand-lightPurple text-brand-purple px-2 py-1 rounded-full">1.2 GB</span>
                    </div>
                    <Progress value={2.4} className="h-2 bg-gray-100" />
                  </div>
                </div>
                
                <Button className="bg-brand-purple hover:bg-brand-purple/90">
                  Upgrade Storage
                </Button>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold mb-4">Manage Storage</h3>
              <div className="space-y-4">
                <Button variant="outline" className="w-full justify-start text-gray-600">
                  <FileText size={16} className="mr-2" /> View All Files
                </Button>
                
                <Button variant="outline" className="w-full justify-start text-gray-600">
                  <Video size={16} className="mr-2" /> Optimize Videos
                </Button>
                
                <Button variant="outline" className="w-full justify-start text-gray-600">
                  <HelpCircle size={16} className="mr-2" /> Storage FAQ
                </Button>
              </div>
              
              <div className="mt-6 pt-4 border-t border-gray-100">
                <h4 className="text-sm font-medium mb-3">Storage Tips</h4>
                <ul className="text-xs text-gray-500 space-y-2">
                  <li className="flex items-start">
                    <span className="inline-block w-1 h-1 bg-gray-400 rounded-full mt-1.5 mr-2"></span>
                    <span>Compress videos before uploading to save space</span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-block w-1 h-1 bg-gray-400 rounded-full mt-1.5 mr-2"></span>
                    <span>Clean up old assignments regularly</span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-block w-1 h-1 bg-gray-400 rounded-full mt-1.5 mr-2"></span>
                    <span>Upload shared resources to the cloud library</span>
                  </li>
                </ul>
              </div>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SupportView;
