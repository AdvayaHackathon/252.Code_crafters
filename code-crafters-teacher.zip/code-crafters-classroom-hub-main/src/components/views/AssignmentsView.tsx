
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { FileText, Upload, Search, Clock, CheckCircle, XCircle, AlertTriangle } from "lucide-react";
import { useNavigation } from "@/context/NavigationContext";
import { checkPlagiarism, isPlagiarized } from "@/lib/assignment-utils";
import { calculateCosineSimilarity, findCommonPhrases, generatePlagiarismReport } from "@/lib/text-comparison";

// Define types
type Assignment = {
  id: string;
  title: string;
  description: string;
  deadline: string;
  status: "draft" | "published";
  submissions: Submission[];
  plagiarismChecked: boolean;
};

type Submission = {
  id: string;
  studentName: string;
  studentId: string;
  submissionDate: string;
  content: string;
  score?: number;
  status: "submitted" | "graded" | "late";
  plagiarismScore?: number;
};

const AssignmentsView = () => {
  const { addAlert } = useNavigation();
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedAssignment, setSelectedAssignment] = useState<Assignment | null>(null);
  const [isPlagiarismDialogOpen, setIsPlagiarismDialogOpen] = useState(false);
  const [plagiarismReport, setPlagiarismReport] = useState<{
    similarityScore: number;
    commonPhrases: string[];
    isPlagiarized: boolean;
    confidence: string;
  } | null>(null);
  
  // Form state for new assignment
  const [newAssignment, setNewAssignment] = useState({
    title: "",
    description: "",
    deadline: "",
  });

  // Update local storage when assignments change
  const updateLocalStorage = (updatedAssignments: Assignment[]) => {
    localStorage.setItem('assignmentCount', updatedAssignments.length.toString());
    
    // Dispatch storage event to notify other components
    const event = new StorageEvent('storage', {
      key: 'assignmentCount',
      newValue: updatedAssignments.length.toString(),
    });
    window.dispatchEvent(event);
  };

  const handleCreateAssignment = () => {
    if (!newAssignment.title || !newAssignment.description || !newAssignment.deadline) {
      toast.error("Please fill in all fields");
      return;
    }
    
    const assignment: Assignment = {
      id: Date.now().toString(),
      title: newAssignment.title,
      description: newAssignment.description,
      deadline: newAssignment.deadline,
      status: "published",
      submissions: [],
      plagiarismChecked: false
    };
    
    const updatedAssignments = [...assignments, assignment];
    setAssignments(updatedAssignments);
    updateLocalStorage(updatedAssignments);
    
    setNewAssignment({
      title: "",
      description: "",
      deadline: "",
    });
    
    toast.success(`Assignment "${assignment.title}" created`);
    addAlert({
      type: "success",
      message: `New assignment created: ${assignment.title}`
    });
  };

  const handleCheckPlagiarism = (assignment: Assignment) => {
    if (assignment.submissions.length < 2) {
      toast.error("Need at least 2 submissions to check for plagiarism");
      return;
    }
    
    // Use the utility functions to check for plagiarism
    const checkedSubmissions = checkPlagiarism(assignment.submissions.map(sub => ({
      id: sub.id,
      title: sub.studentName,
      content: sub.content,
      studentId: sub.studentId,
      studentName: sub.studentName,
      submissionDate: new Date(sub.submissionDate)
    })));
    
    // Update submissions with plagiarism scores
    const updatedAssignment = {
      ...assignment,
      submissions: assignment.submissions.map(sub => {
        const checked = checkedSubmissions.find(cs => cs.id === sub.id);
        return {
          ...sub,
          plagiarismScore: checked?.plagiarismScore
        };
      }),
      plagiarismChecked: true
    };
    
    // Update assignments state
    const newAssignments = assignments.map(a => 
      a.id === updatedAssignment.id ? updatedAssignment : a
    );
    
    setAssignments(newAssignments);
    setSelectedAssignment(updatedAssignment);
    
    // Show alert for plagiarism detection
    const plagiarizedCount = updatedAssignment.submissions.filter(
      sub => isPlagiarized(sub.plagiarismScore)
    ).length;
    
    if (plagiarizedCount > 0) {
      addAlert({
        type: "warning",
        message: `Plagiarism detected in ${plagiarizedCount} submission(s)!`
      });
    } else {
      toast.success("No plagiarism detected");
    }
  };

  const handleViewPlagiarismDetails = (submission1: Submission, submission2: Submission) => {
    if (!submission1.content || !submission2.content) {
      toast.error("Missing submission content");
      return;
    }
    
    const report = generatePlagiarismReport(submission1.content, submission2.content);
    setPlagiarismReport(report);
    setIsPlagiarismDialogOpen(true);
  };

  const handleGradeSubmission = (assignmentId: string, submissionId: string, score: number) => {
    if (score < 0 || score > 100) {
      toast.error("Score must be between 0 and 100");
      return;
    }
    
    const updatedAssignments = assignments.map(assignment => {
      if (assignment.id === assignmentId) {
        return {
          ...assignment,
          submissions: assignment.submissions.map(submission => {
            if (submission.id === submissionId) {
              return {
                ...submission,
                score,
                status: "graded" as const
              };
            }
            return submission;
          })
        };
      }
      return assignment;
    });
    
    setAssignments(updatedAssignments);
    setSelectedAssignment(updatedAssignments.find(a => a.id === assignmentId) || null);
    toast.success("Submission graded successfully");
  };

  const filteredAssignments = assignments.filter(assignment => 
    assignment.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    assignment.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold mb-1 gradient-text">Assignments</h1>
          <p className="text-gray-400 mb-4">
            Create, manage and grade student assignments
          </p>
        </div>
        
        <div className="flex gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-300" size={16} />
            <Input
              placeholder="Search assignments..."
              className="pl-9 glass-input"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
            />
          </div>
          
          <Dialog>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-brand-purple to-brand-neonBlue hover:opacity-90">
                <FileText size={16} className="mr-1" /> Create Assignment
              </Button>
            </DialogTrigger>
            <DialogContent className="glass">
              <DialogHeader>
                <DialogTitle>Create New Assignment</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    placeholder="Enter assignment title"
                    value={newAssignment.title}
                    onChange={e => setNewAssignment({ ...newAssignment, title: e.target.value })}
                    className="glass-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Enter assignment details and instructions"
                    value={newAssignment.description}
                    onChange={e => setNewAssignment({ ...newAssignment, description: e.target.value })}
                    className="glass-input min-h-[100px]"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="deadline">Deadline</Label>
                  <Input
                    id="deadline"
                    type="date"
                    value={newAssignment.deadline}
                    onChange={e => setNewAssignment({ ...newAssignment, deadline: e.target.value })}
                    className="glass-input"
                  />
                </div>
                <Button 
                  className="w-full bg-gradient-to-r from-brand-purple to-brand-neonBlue hover:opacity-90"
                  onClick={handleCreateAssignment}
                >
                  Create Assignment
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      {selectedAssignment ? (
        <div>
          <Button
            variant="outline"
            onClick={() => setSelectedAssignment(null)}
            className="mb-4"
          >
            Back to All Assignments
          </Button>
          
          <Card className="glass-card p-5 mb-6">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-xl font-semibold">{selectedAssignment.title}</h2>
                <p className="text-gray-400 mt-1">
                  Due: {new Date(selectedAssignment.deadline).toLocaleDateString()}
                </p>
              </div>
              <Badge 
                variant={selectedAssignment.status === "published" ? "default" : "outline"}
                className="bg-brand-purple"
              >
                {selectedAssignment.status}
              </Badge>
            </div>
            <div className="mt-4 text-gray-300">
              <p>{selectedAssignment.description}</p>
            </div>
          </Card>
          
          <Card className="glass-card p-5">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-semibold">Submissions</h3>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  className="glass-button text-purple-300"
                  onClick={() => handleCheckPlagiarism(selectedAssignment)}
                  disabled={selectedAssignment.submissions.length < 2}
                >
                  <AlertTriangle size={16} className="mr-1" /> Check Plagiarism
                </Button>
              </div>
            </div>
            
            {selectedAssignment.submissions.length > 0 ? (
              <div className="rounded-md border border-white/10 glass overflow-hidden">
                <Table>
                  <TableHeader className="bg-black/20">
                    <TableRow className="border-white/10 hover:bg-transparent">
                      <TableHead className="text-purple-300">Student</TableHead>
                      <TableHead className="text-purple-300">Date</TableHead>
                      <TableHead className="text-purple-300">Status</TableHead>
                      <TableHead className="text-purple-300">Score</TableHead>
                      {selectedAssignment.plagiarismChecked && (
                        <TableHead className="text-purple-300">Plagiarism</TableHead>
                      )}
                      <TableHead className="text-purple-300 text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedAssignment.submissions.map((submission) => (
                      <TableRow key={submission.id} className="border-white/10 hover:bg-black/20">
                        <TableCell className="font-medium text-white">{submission.studentName}</TableCell>
                        <TableCell className="text-gray-300">
                          {new Date(submission.submissionDate).toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant="outline"
                            className={
                              submission.status === "graded" ? "bg-green-900/50 text-green-300" :
                              submission.status === "late" ? "bg-amber-900/50 text-amber-300" :
                              "bg-blue-900/50 text-blue-300"
                            }
                          >
                            {submission.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {submission.status === "graded" ? (
                            <span className="text-gray-300">{submission.score}/100</span>
                          ) : (
                            <span className="text-gray-500">Not graded</span>
                          )}
                        </TableCell>
                        
                        {selectedAssignment.plagiarismChecked && (
                          <TableCell>
                            {submission.plagiarismScore !== undefined ? (
                              <Badge 
                                variant="outline"
                                className={
                                  isPlagiarized(submission.plagiarismScore)
                                    ? "bg-red-900/50 text-red-300"
                                    : "bg-green-900/50 text-green-300"
                                }
                              >
                                {submission.plagiarismScore}%
                              </Badge>
                            ) : (
                              <span>-</span>
                            )}
                          </TableCell>
                        )}
                        
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button 
                              variant="ghost" 
                              size="sm"
                              className="text-purple-300 hover:bg-white/10"
                              onClick={() => {
                                // Mock grading function - in a real app, this would open a detailed view
                                const score = Math.floor(Math.random() * 40) + 60; // Random score between 60-100
                                handleGradeSubmission(selectedAssignment.id, submission.id, score);
                              }}
                            >
                              Grade
                            </Button>
                            
                            {isPlagiarized(submission.plagiarismScore) && (
                              <Button 
                                variant="ghost" 
                                size="sm"
                                className="text-red-300 hover:bg-red-950/30"
                                onClick={() => {
                                  // Find another submission with high similarity to show comparison
                                  const otherSubmission = selectedAssignment.submissions.find(s => 
                                    s.id !== submission.id && isPlagiarized(s.plagiarismScore)
                                  );
                                  
                                  if (otherSubmission) {
                                    handleViewPlagiarismDetails(submission, otherSubmission);
                                  } else {
                                    toast.error("No matching submission found for comparison");
                                  }
                                }}
                              >
                                View Issues
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center py-10 text-gray-400">
                <FileText size={30} className="mx-auto mb-3 opacity-50" />
                <p>No submissions yet</p>
              </div>
            )}
          </Card>
        </div>
      ) : (
        <>
          <Tabs defaultValue="active" className="w-full">
            <TabsList className="grid grid-cols-2 w-full max-w-md glass">
              <TabsTrigger value="active">Active</TabsTrigger>
              <TabsTrigger value="draft">Drafts</TabsTrigger>
            </TabsList>
            
            <TabsContent value="active" className="mt-6">
              {filteredAssignments.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredAssignments
                    .filter(a => a.status === "published")
                    .map((assignment) => (
                      <Card 
                        key={assignment.id} 
                        className="glass-card hover:scale-[1.02] transition-transform cursor-pointer"
                        onClick={() => setSelectedAssignment(assignment)}
                      >
                        <div className="p-5">
                          <h3 className="font-medium text-lg">{assignment.title}</h3>
                          <div className="flex items-center gap-2 mt-1 text-sm text-gray-400">
                            <Clock size={14} />
                            <span>Due: {new Date(assignment.deadline).toLocaleDateString()}</span>
                          </div>
                          <p className="text-sm text-gray-300 mt-3 line-clamp-2">
                            {assignment.description}
                          </p>
                          <div className="flex justify-between items-center mt-4">
                            <Badge variant="outline" className="bg-brand-purple/30">
                              {assignment.submissions.length} submissions
                            </Badge>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              className="text-purple-300"
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedAssignment(assignment);
                              }}
                            >
                              View Details
                            </Button>
                          </div>
                        </div>
                      </Card>
                    ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="glass-card p-8 max-w-md mx-auto">
                    <FileText size={40} className="mx-auto mb-3 opacity-50" />
                    <h3 className="text-xl font-medium mb-2">No assignments yet</h3>
                    <p className="text-gray-400 mb-4">
                      Create your first assignment to start grading student work.
                    </p>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button className="bg-gradient-to-r from-brand-purple to-brand-neonBlue">
                          <FileText size={16} className="mr-1" /> Create First Assignment
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="glass">
                        {/* Same dialog content as above */}
                        <DialogHeader>
                          <DialogTitle>Create New Assignment</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <Label htmlFor="title-first">Title</Label>
                            <Input
                              id="title-first"
                              placeholder="Enter assignment title"
                              value={newAssignment.title}
                              onChange={e => setNewAssignment({ ...newAssignment, title: e.target.value })}
                              className="glass-input"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="description-first">Description</Label>
                            <Textarea
                              id="description-first"
                              placeholder="Enter assignment details and instructions"
                              value={newAssignment.description}
                              onChange={e => setNewAssignment({ ...newAssignment, description: e.target.value })}
                              className="glass-input min-h-[100px]"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="deadline-first">Deadline</Label>
                            <Input
                              id="deadline-first"
                              type="date"
                              value={newAssignment.deadline}
                              onChange={e => setNewAssignment({ ...newAssignment, deadline: e.target.value })}
                              className="glass-input"
                            />
                          </div>
                          <Button 
                            className="w-full bg-gradient-to-r from-brand-purple to-brand-neonBlue hover:opacity-90"
                            onClick={handleCreateAssignment}
                          >
                            Create Assignment
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="draft" className="mt-6">
              {/* Similar structure for drafts */}
              <div className="text-center py-12">
                <div className="glass-card p-8 max-w-md mx-auto">
                  <FileText size={40} className="mx-auto mb-3 opacity-50" />
                  <h3 className="text-xl font-medium mb-2">No draft assignments</h3>
                  <p className="text-gray-400 mb-4">
                    Drafts will appear here once you create them.
                  </p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </>
      )}
      
      {/* Plagiarism comparison dialog */}
      <Dialog open={isPlagiarismDialogOpen} onOpenChange={setIsPlagiarismDialogOpen}>
        <DialogContent className="glass max-w-4xl">
          <DialogHeader>
            <DialogTitle>Plagiarism Detection Results</DialogTitle>
          </DialogHeader>
          {plagiarismReport && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium">
                  Similarity Score: {plagiarismReport.similarityScore}%
                </h3>
                <Badge 
                  variant="outline"
                  className={
                    plagiarismReport.isPlagiarized 
                      ? "bg-red-900/50 text-red-300" 
                      : "bg-green-900/50 text-green-300"
                  }
                >
                  {plagiarismReport.confidence.toUpperCase()} CONFIDENCE
                </Badge>
              </div>
              
              <div>
                <h4 className="font-medium mb-2">Common Phrases Detected:</h4>
                <div className="space-y-2 max-h-60 overflow-y-auto glass p-3">
                  {plagiarismReport.commonPhrases.length > 0 ? (
                    plagiarismReport.commonPhrases.map((phrase, index) => (
                      <div key={index} className="p-2 glass-card">
                        <p className="text-sm text-yellow-300">"{phrase}"</p>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-400">No specific common phrases detected</p>
                  )}
                </div>
              </div>
              
              <div className="mt-2">
                <Button 
                  className="w-full"
                  onClick={() => setIsPlagiarismDialogOpen(false)}
                >
                  Close
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AssignmentsView;
