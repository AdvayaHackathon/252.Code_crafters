
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import StudentList from "../students/StudentList"; 
import { 
  Plus, 
  Search, 
  Users, 
  PlusCircle,
  Edit,
  Trash2
} from "lucide-react";
import { toast } from "sonner";
import { useUser } from "@/context/UserContext";

type Student = {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
};

type Classroom = {
  id: string;
  name: string;
  description: string;
  students: Student[];
};

const ClassroomView = () => {
  const { user } = useUser();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isStudentDialogOpen, setIsStudentDialogOpen] = useState(false);
  const [selectedClassroom, setSelectedClassroom] = useState<Classroom | null>(null);
  
  const [newClassroom, setNewClassroom] = useState({
    name: "",
    description: "",
  });
  
  const [newStudent, setNewStudent] = useState({
    name: "",
    email: "",
  });
  
  const [classrooms, setClassrooms] = useState<Classroom[]>([
    {
      id: "1",
      name: `${user.subject} - Class A`,
      description: "Introductory class covering the basics",
      students: [
        { id: "1", name: "Alex Johnson", email: "alex@example.com" },
        { id: "2", name: "Samantha Lee", email: "samantha@example.com" },
        { id: "3", name: "Marcus Chen", email: "marcus@example.com" },
      ]
    },
    {
      id: "2",
      name: `${user.subject} - Class B`,
      description: "Intermediate level concepts and applications",
      students: [
        { id: "4", name: "Taylor Wong", email: "taylor@example.com" },
        { id: "5", name: "Jordan Smith", email: "jordan@example.com" },
      ]
    },
    {
      id: "3",
      name: `${user.subject} - Advanced`,
      description: "Advanced topics for experienced students",
      students: [
        { id: "6", name: "Riley Garcia", email: "riley@example.com" },
      ]
    },
  ]);

  const handleCreateClassroom = () => {
    if (!newClassroom.name.trim()) {
      toast.error("Please provide a classroom name");
      return;
    }

    const classroom: Classroom = {
      id: Date.now().toString(),
      name: newClassroom.name,
      description: newClassroom.description || "No description provided",
      students: []
    };

    setClassrooms([...classrooms, classroom]);
    setNewClassroom({ name: "", description: "" });
    setIsCreateDialogOpen(false);
    toast.success(`Classroom "${newClassroom.name}" created successfully`);
  };

  const handleAddStudent = () => {
    if (!selectedClassroom) {
      toast.error("No classroom selected");
      return;
    }
    
    if (!newStudent.name.trim() || !newStudent.email.trim()) {
      toast.error("Please provide student name and email");
      return;
    }
    
    const student: Student = {
      id: Date.now().toString(),
      name: newStudent.name,
      email: newStudent.email
    };
    
    const updatedClassrooms = classrooms.map((c) => {
      if (c.id === selectedClassroom.id) {
        return {
          ...c,
          students: [...c.students, student]
        };
      }
      return c;
    });
    
    setClassrooms(updatedClassrooms);
    setSelectedClassroom(prev => prev ? {
      ...prev,
      students: [...prev.students, student]
    } : null);
    
    setNewStudent({ name: "", email: "" });
    setIsStudentDialogOpen(false);
    toast.success(`Student "${newStudent.name}" added to ${selectedClassroom.name}`);
  };

  const handleViewClassroomDetails = (classroom: Classroom) => {
    setSelectedClassroom(classroom);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold mb-1">Classrooms</h1>
          <p className="text-gray-600">
            Manage your virtual classrooms and student groups
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              className="bg-brand-purple hover:bg-brand-purple/90 sm:self-start"
            >
              <Plus size={16} className="mr-1" /> New Classroom
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md glass">
            <DialogHeader>
              <DialogTitle>Create New Classroom</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="classroom-name">Classroom Name</Label>
                <Input 
                  id="classroom-name" 
                  placeholder="Enter classroom name"
                  value={newClassroom.name}
                  onChange={(e) => setNewClassroom(prev => ({ ...prev, name: e.target.value }))}
                  className="glass-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="classroom-description">Description</Label>
                <Textarea 
                  id="classroom-description" 
                  placeholder="Enter classroom description"
                  value={newClassroom.description}
                  onChange={(e) => setNewClassroom(prev => ({ ...prev, description: e.target.value }))}
                  className="glass-input"
                />
              </div>
              <Button 
                className="w-full bg-brand-purple hover:bg-brand-purple/90" 
                onClick={handleCreateClassroom}
              >
                Create Classroom
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {selectedClassroom ? (
        <div>
          <Button 
            variant="outline" 
            onClick={() => setSelectedClassroom(null)} 
            className="mb-4"
          >
            Back to All Classrooms
          </Button>
          
          <Card className="glass-card p-5 mb-4">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-xl font-semibold">{selectedClassroom.name}</h2>
                <p className="text-gray-600 mt-1">{selectedClassroom.description}</p>
              </div>
              <div>
                <Button variant="outline" className="mr-2">
                  <Edit size={16} className="mr-1" /> Edit
                </Button>
              </div>
            </div>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="glass-card p-5 md:col-span-2">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold">Students ({selectedClassroom.students.length})</h3>
                <Dialog open={isStudentDialogOpen} onOpenChange={setIsStudentDialogOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <Plus size={16} className="mr-1" /> Add Student
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md glass">
                    <DialogHeader>
                      <DialogTitle>Add Student to {selectedClassroom.name}</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="student-name">Student Name</Label>
                        <Input 
                          id="student-name" 
                          placeholder="Enter student name"
                          value={newStudent.name}
                          onChange={(e) => setNewStudent(prev => ({ ...prev, name: e.target.value }))}
                          className="glass-input"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="student-email">Student Email</Label>
                        <Input 
                          id="student-email" 
                          type="email"
                          placeholder="Enter student email"
                          value={newStudent.email}
                          onChange={(e) => setNewStudent(prev => ({ ...prev, email: e.target.value }))}
                          className="glass-input"
                        />
                      </div>
                      <Button 
                        className="w-full bg-brand-purple hover:bg-brand-purple/90" 
                        onClick={handleAddStudent}
                      >
                        Add Student
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
              
              {selectedClassroom.students.length > 0 ? (
                <div className="space-y-2">
                  {selectedClassroom.students.map((student) => (
                    <div 
                      key={student.id}
                      className="flex items-center justify-between p-3 bg-white/40 hover:bg-white/60 rounded-md transition-colors"
                    >
                      <div className="flex items-center">
                        <div className="h-8 w-8 rounded-full bg-brand-purple flex items-center justify-center text-white mr-3">
                          {student.name.split(' ').map(n => n[0]).join('')}
                        </div>
                        <div>
                          <div className="font-medium">{student.name}</div>
                          <div className="text-sm text-gray-500">{student.email}</div>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" className="text-red-500 hover:bg-red-50 hover:text-red-600">
                        <Trash2 size={16} />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Users className="h-10 w-10 text-gray-300 mx-auto mb-2" />
                  <p className="text-gray-500">No students yet</p>
                </div>
              )}
            </Card>
            
            <Card className="glass-card p-5">
              <h3 className="font-semibold mb-4">Classroom Schedule</h3>
              <div className="text-center py-8">
                <p className="text-gray-500">No scheduled classes yet</p>
                <Button className="mt-4 bg-brand-purple hover:bg-brand-purple/90">
                  <Plus size={16} className="mr-1" /> Schedule Class
                </Button>
              </div>
            </Card>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {classrooms.map((classroom) => (
            <Card 
              key={classroom.id} 
              className="glass-card p-5 hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => handleViewClassroomDetails(classroom)}
            >
              <div className="flex justify-between items-start mb-4">
                <h3 className="font-medium">{classroom.name}</h3>
              </div>
              <p className="text-sm text-gray-500 mb-4 line-clamp-2">{classroom.description}</p>
              <div className="flex items-center text-sm text-gray-500 mb-4">
                <Users size={16} className="mr-1" />
                <span>{classroom.students.length} Students</span>
              </div>
              <Button className="w-full bg-brand-purple hover:bg-brand-purple/90">
                View Details
              </Button>
            </Card>
          ))}
          
          <Card 
            className="glass-card p-5 border-dashed hover:shadow-md transition-colors cursor-pointer flex flex-col items-center justify-center min-h-[230px]" 
            onClick={() => setIsCreateDialogOpen(true)}
          >
            <div className="p-4 rounded-full bg-brand-lightPurple mb-3">
              <Plus size={24} className="text-brand-purple" />
            </div>
            <h3 className="font-medium mb-2">Create Classroom</h3>
            <p className="text-sm text-gray-500 text-center">
              Add a new virtual classroom for your students
            </p>
          </Card>
        </div>
      )}
    </div>
  );
};

export default ClassroomView;
