
import { useState } from 'react';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

type Event = {
  id: string;
  title: string;
  date: Date;
  type: 'class' | 'assignment' | 'meeting';
};

type CalendarProps = {
  className?: string;
  events?: Event[];
};

const Calendar = ({ className, events = [] }: CalendarProps) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  
  const daysInMonth = new Date(
    currentDate.getFullYear(),
    currentDate.getMonth() + 1,
    0
  ).getDate();
  
  const firstDayOfMonth = new Date(
    currentDate.getFullYear(),
    currentDate.getMonth(),
    1
  ).getDay();
  
  const monthName = currentDate.toLocaleString('default', { month: 'long' });
  const year = currentDate.getFullYear();
  
  const handlePreviousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };
  
  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };
  
  const isToday = (day: number) => {
    const today = new Date();
    return day === today.getDate() &&
      currentDate.getMonth() === today.getMonth() &&
      currentDate.getFullYear() === today.getFullYear();
  };
  
  const hasEvent = (day: number) => {
    return events.some(event => {
      const eventDate = new Date(event.date);
      return eventDate.getDate() === day &&
        eventDate.getMonth() === currentDate.getMonth() &&
        eventDate.getFullYear() === currentDate.getFullYear();
    });
  };
  
  const getEventType = (day: number) => {
    const event = events.find(event => {
      const eventDate = new Date(event.date);
      return eventDate.getDate() === day &&
        eventDate.getMonth() === currentDate.getMonth() &&
        eventDate.getFullYear() === currentDate.getFullYear();
    });
    
    return event?.type || null;
  };

  const getDayClasses = (day: number) => {
    const eventType = getEventType(day);
    
    let classes = "h-8 w-8 rounded-full flex items-center justify-center text-sm";
    
    if (isToday(day)) {
      classes += " bg-brand-purple text-white";
    } else if (eventType) {
      switch(eventType) {
        case 'class':
          classes += " bg-brand-lightPurple text-brand-purple";
          break;
        case 'assignment':
          classes += " bg-amber-100 text-amber-600";
          break;
        case 'meeting':
          classes += " bg-blue-100 text-blue-600";
          break;
      }
    } else {
      classes += " hover:bg-gray-100";
    }
    
    return classes;
  };
  
  return (
    <Card className={cn("p-4", className)}>
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-semibold text-lg">{monthName} {year}</h2>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="icon" 
            className="h-8 w-8"
            onClick={handlePreviousMonth}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button 
            variant="outline" 
            size="icon" 
            className="h-8 w-8"
            onClick={handleNextMonth}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-7 gap-1 text-center">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
          <div key={day} className="text-xs font-medium text-gray-500 py-1">
            {day}
          </div>
        ))}
        
        {Array(firstDayOfMonth).fill(null).map((_, i) => (
          <div key={`empty-${i}`} className="h-8"></div>
        ))}
        
        {Array.from({ length: daysInMonth }).map((_, i) => {
          const day = i + 1;
          return (
            <div key={`day-${day}`} className="relative">
              <button className={getDayClasses(day)}>
                {day}
              </button>
              {hasEvent(day) && !isToday(day) && (
                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1 h-1 rounded-full bg-brand-purple"></div>
              )}
            </div>
          );
        })}
      </div>
      
      <div className="mt-4 border-t pt-3">
        <h3 className="font-medium text-sm mb-2">Upcoming Events</h3>
        {events.length > 0 ? (
          <div className="space-y-2">
            {events.slice(0, 3).map(event => {
              const eventDate = new Date(event.date);
              return (
                <div key={event.id} className="flex items-center text-sm">
                  <div 
                    className={cn(
                      "w-2 h-2 rounded-full mr-2",
                      event.type === 'class' ? "bg-brand-purple" : 
                      event.type === 'assignment' ? "bg-amber-500" : 
                      "bg-blue-500"
                    )}
                  ></div>
                  <span className="flex-1">{event.title}</span>
                  <span className="text-xs text-gray-500">
                    {eventDate.toLocaleDateString([], {month: 'short', day: 'numeric'})}
                  </span>
                </div>
              );
            })}
          </div>
        ) : (
          <p className="text-sm text-gray-500">No upcoming events</p>
        )}
      </div>
    </Card>
  );
};

export default Calendar;
