
import { ReactNode } from "react";
import { useUser } from "@/context/UserContext";
import { useNavigation } from "@/context/NavigationContext";
import SidebarNavigation from "./SidebarNavigation";
import Header from "./Header";
import DashboardView from "./views/DashboardView";
import ClassroomView from "./views/ClassroomView";
import LiveLessonsView from "./views/LiveLessonsView";
import RecordedLessonsView from "./views/RecordedLessonsView";
import AssignmentsView from "./views/AssignmentsView";
import { cn } from "@/lib/utils";

type LayoutProps = {
  children?: ReactNode;
};

const Layout = ({ children }: LayoutProps) => {
  const { activeItem, isSidebarCollapsed } = useNavigation();
  
  const renderContent = () => {
    switch (activeItem) {
      case "dashboard":
        return <DashboardView />;
      case "classroom":
        return <ClassroomView />;
      case "live-lessons":
        return <LiveLessonsView />;
      case "recorded-lessons":
        return <RecordedLessonsView />;
      case "assignments":
        return <AssignmentsView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-grid-pattern bg-[size:40px_40px] animated-grid-bg">
      <SidebarNavigation />
      
      <div className={cn(
        "flex flex-col flex-1 overflow-hidden transition-all duration-300",
        isSidebarCollapsed ? "ml-20" : "ml-64"
      )}>
        <Header />
        
        <main className="flex-1 overflow-y-auto">
          {renderContent()}
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;
