
import { Bell, Search, User, AlertTriangle } from "lucide-react";
import { useUser } from "../context/UserContext";
import { useNavigation } from "../context/NavigationContext";
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const Header = () => {
  const { user } = useUser();
  const { alerts, markAlertAsRead } = useNavigation();
  
  const currentDate = new Date();
  const dateOptions: Intl.DateTimeFormatOptions = { 
    day: 'numeric', 
    month: 'long', 
    year: 'numeric', 
    weekday: 'long' 
  };
  const formattedDate = currentDate.toLocaleDateString('en-US', dateOptions);
  const unreadAlerts = alerts.filter(alert => !alert.read);

  return (
    <div className="glass-header py-3 px-6 flex justify-between items-center">
      <div className="flex items-center space-x-4 flex-1">
        <div className="relative w-full max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-300" size={18} />
          <input
            type="text"
            placeholder="Search..."
            className="pl-10 pr-4 py-2 glass-input rounded-md w-full focus:outline-none focus:ring-2 focus:ring-brand-purple focus:border-transparent"
          />
        </div>
        <div className="text-sm text-gray-300 hidden md:block gradient-text font-medium">
          {formattedDate}
        </div>
      </div>

      <div className="flex items-center space-x-4">
        <HoverCard>
          <HoverCardTrigger asChild>
            <button className="p-2 rounded-full hover:bg-black/30 relative transition-all duration-200">
              <Bell size={20} className="text-purple-300" />
              {unreadAlerts.length > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
              )}
            </button>
          </HoverCardTrigger>
          <HoverCardContent className="w-80 glass border-white/10">
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-purple-300">Notifications</h4>
              {alerts.length > 0 ? (
                <div className="space-y-2 max-h-60 overflow-auto">
                  {alerts.slice(0, 5).map((alert) => (
                    <div 
                      key={alert.id} 
                      className={cn(
                        "p-2 rounded-md text-sm border-l-2",
                        !alert.read && "bg-black/40",
                        alert.type === "warning" && "border-yellow-500",
                        alert.type === "success" && "border-green-500",
                        alert.type === "error" && "border-red-500",
                        alert.type === "info" && "border-blue-500",
                      )}
                      onClick={() => markAlertAsRead(alert.id)}
                    >
                      <div className="flex items-start gap-2">
                        {alert.type === "warning" && <AlertTriangle size={16} className="text-yellow-500 mt-0.5" />}
                        <div>
                          <p className="text-white">{alert.message}</p>
                          <p className="text-xs text-gray-400 mt-1">
                            {alert.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-400">No notifications</p>
              )}
              {alerts.length > 0 && (
                <Button variant="outline" size="sm" className="w-full text-xs glass-button text-purple-300 mt-2">
                  View all notifications
                </Button>
              )}
            </div>
          </HoverCardContent>
        </HoverCard>
        <div className="flex items-center space-x-2">
          <div className="w-10 h-10 bg-gradient-to-br from-brand-purple to-brand-neonBlue rounded-full flex items-center justify-center neon-glow-purple">
            <User className="text-white" size={20} />
          </div>
          <div className="hidden md:block">
            <div className="text-sm font-medium text-white">{user?.name || "Teacher"}</div>
            <div className="text-xs text-purple-300">{user?.subject || "Subject"}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;
