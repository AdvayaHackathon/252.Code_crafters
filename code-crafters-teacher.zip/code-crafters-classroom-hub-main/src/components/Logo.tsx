
import React from "react";

type LogoProps = {
  collapsed?: boolean;
};

const Logo = ({ collapsed = false }: LogoProps) => {
  return (
    <div className="flex items-center gap-2 py-6 px-4">
      <div className="flex items-center justify-center w-8 h-8 bg-gradient-to-br from-brand-purple to-brand-blue rounded">
        <span className="text-white font-bold">CC</span>
      </div>
      {!collapsed && (
        <span className="font-bold text-lg text-gray-800">Code Crafters</span>
      )}
    </div>
  );
};

export default Logo;
