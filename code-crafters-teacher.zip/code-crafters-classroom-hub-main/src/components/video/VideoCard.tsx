
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileVideo, Calendar, Users, Edit, PlayCircle, MoreHorizontal } from "lucide-react";
import { cn } from "@/lib/utils";
import { VideoLesson } from "@/types/video";

interface VideoCardProps {
  video: VideoLesson;
  onPlay: (videoId: string) => void;
  onEdit: (videoId: string) => void;
}

const VideoCard = ({ video, onPlay, onEdit }: VideoCardProps) => {
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  return (
    <Card className="glass-card overflow-hidden hover-scale transition-all duration-300">
      <div className="relative bg-black/40 h-40 flex items-center justify-center">
        {video.videoUrl ? (
          <img 
            src={`${video.videoUrl}#t=0.5`} 
            alt={video.title}
            className="w-full h-full object-contain"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.src = ""; // Clear the errored image
              target.style.display = "none";
              const parent = target.parentElement;
              if (parent) {
                const fallback = document.createElement('div');
                fallback.innerHTML = `<div class="flex items-center justify-center h-full w-full"><FileVideo size="48" class="text-gray-400" /></div>`;
                parent.appendChild(fallback.firstChild as Node);
              }
            }}
          />
        ) : (
          <FileVideo size={48} className="text-gray-400" />
        )}
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute top-2 right-2 h-8 w-8 bg-black/20 hover:bg-black/40 text-white rounded-full"
          onClick={() => onEdit(video.id)}
        >
          <MoreHorizontal size={16} />
        </Button>
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute inset-0 m-auto h-12 w-12 bg-black/30 hover:bg-black/50 text-white rounded-full neon-glow-blue animate-pulse-glow"
          onClick={() => onPlay(video.id)}
        >
          <PlayCircle size={24} />
        </Button>
        <div className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded">
          {video.duration}
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-medium mb-1 text-white truncate">{video.title}</h3>
        <div className="flex items-center justify-between text-xs text-gray-400 mb-3">
          <div className="flex items-center">
            <Calendar size={12} className="mr-1 text-purple-300" />
            <span>{formatDate(video.uploadDate)}</span>
          </div>
          <div className="flex items-center">
            <Users size={12} className="mr-1 text-purple-300" />
            <span>{video.views} views</span>
          </div>
        </div>
        <div className="flex justify-between items-center">
          <span 
            className={cn(
              "text-xs px-2 py-1 rounded-full",
              video.topic === "Basics" ? "bg-green-900/50 text-green-300" :
              video.topic === "Fundamentals" ? "bg-blue-900/50 text-blue-300" :
              video.topic === "Advanced" ? "bg-purple-900/50 text-purple-300" :
              "bg-gray-900/50 text-gray-300"
            )}
          >
            {video.topic}
          </span>
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-8 w-8 text-purple-300 hover:bg-white/10"
            onClick={() => onEdit(video.id)}
          >
            <Edit size={14} />
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default VideoCard;
