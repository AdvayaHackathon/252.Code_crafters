
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, X, FileVideo, CheckCircle } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type VideoUploaderProps = {
  className?: string;
  onUploadComplete?: (videoData: { name: string; size: number; url: string }) => void;
};

const VideoUploader = ({ className, onUploadComplete }: VideoUploaderProps) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };
  
  const handleDragLeave = () => {
    setIsDragging(false);
  };
  
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    processFiles(files);
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      processFiles(files);
    }
  };
  
  const processFiles = (files: FileList) => {
    // Check if there are files
    if (files.length === 0) return;
    
    // Check if file is video
    const file = files[0];
    if (!file.type.startsWith('video/')) {
      toast.error('Please upload a video file');
      return;
    }
    
    // Check file size (limit to 500MB for demo)
    if (file.size > 500 * 1024 * 1024) {
      toast.error('File size exceeds 500MB limit');
      return;
    }
    
    // Start mock upload
    setUploadedFile(file);
    simulateUpload(file);
  };
  
  const simulateUpload = (file: File) => {
    setIsUploading(true);
    setUploadProgress(0);
    
    // Simulate an upload with progress
    const totalSteps = 100;
    let currentStep = 0;
    
    const uploadInterval = setInterval(() => {
      currentStep += 1;
      const newProgress = Math.min(Math.round((currentStep / totalSteps) * 100), 100);
      setUploadProgress(newProgress);
      
      if (newProgress >= 100) {
        clearInterval(uploadInterval);
        setTimeout(() => {
          setIsUploading(false);
          toast.success('Video uploaded successfully');
          
          if (onUploadComplete) {
            onUploadComplete({
              name: file.name,
              size: file.size,
              url: URL.createObjectURL(file)
            });
          }
        }, 500);
      }
    }, 50);
  };
  
  const cancelUpload = () => {
    setIsUploading(false);
    setUploadProgress(0);
    setUploadedFile(null);
    toast.info('Upload canceled');
  };
  
  return (
    <Card 
      className={cn(
        "p-6", 
        className
      )}
    >
      <div className="flex flex-col items-center justify-center">
        <h2 className="text-xl font-semibold mb-2">Upload Video Lesson</h2>
        <p className="text-gray-500 text-sm mb-6 text-center">
          Upload your recorded lessons in MP4, MOV, or AVI format
        </p>
        
        {!isUploading && !uploadedFile ? (
          <div
            className={cn(
              "border-2 border-dashed rounded-lg p-8 w-full max-w-md text-center cursor-pointer transition-colors",
              isDragging ? "border-brand-purple bg-brand-lightPurple/50" : "border-gray-300 hover:border-brand-purple"
            )}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => document.getElementById('file-upload')?.click()}
          >
            <input 
              id="file-upload" 
              type="file" 
              className="hidden" 
              accept="video/*"
              onChange={handleFileChange}
            />
            <Upload 
              className={cn(
                "mx-auto mb-4",
                isDragging ? "text-brand-purple" : "text-gray-400" 
              )} 
              size={40} 
            />
            <h3 className="font-medium mb-1">Drag and drop your video</h3>
            <p className="text-sm text-gray-500 mb-4">or click to browse</p>
            <Button className="bg-brand-purple hover:bg-brand-purple/90">
              Select Video
            </Button>
            <p className="mt-4 text-xs text-gray-400">
              Max file size: 500MB
            </p>
          </div>
        ) : isUploading ? (
          <div className="border rounded-lg p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <FileVideo className="text-brand-purple mr-3" size={24} />
                <div className="truncate max-w-[200px]">
                  <p className="font-medium text-sm truncate">{uploadedFile?.name}</p>
                  <p className="text-xs text-gray-500">
                    {Math.round((uploadedFile?.size || 0) / 1024 / 1024)}MB
                  </p>
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 text-gray-500"
                onClick={cancelUpload}
              >
                <X size={18} />
              </Button>
            </div>
            <div className="space-y-2">
              <Progress value={uploadProgress} className="h-2" />
              <div className="flex justify-between items-center text-xs text-gray-500">
                <span>Uploading...</span>
                <span>{uploadProgress}%</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="border rounded-lg p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <FileVideo className="text-brand-purple mr-3" size={24} />
                <div>
                  <p className="font-medium text-sm truncate max-w-[200px]">
                    {uploadedFile?.name}
                  </p>
                  <p className="text-xs text-gray-500">
                    {Math.round((uploadedFile?.size || 0) / 1024 / 1024)}MB
                  </p>
                </div>
              </div>
              <CheckCircle className="text-green-500" size={20} />
            </div>
            <p className="text-sm text-gray-500">Upload complete!</p>
            <div className="mt-4 flex space-x-2">
              <Button 
                className="flex-1 bg-brand-purple hover:bg-brand-purple/90"
                onClick={() => {
                  setUploadedFile(null);
                  toast.success("Video processed successfully");
                }}
              >
                Process Video
              </Button>
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => {
                  setUploadedFile(null);
                }}
              >
                Upload Another
              </Button>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
};

export default VideoUploader;
