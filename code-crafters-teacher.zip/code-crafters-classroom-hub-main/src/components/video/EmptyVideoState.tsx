
import { FileVideo } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface EmptyVideoStateProps {
  onUpload: () => void;
}

const EmptyVideoState = ({ onUpload }: EmptyVideoStateProps) => {
  return (
    <Card className="glass-card p-10 text-center">
      <div className="mb-4">
        <FileVideo size={40} className="mx-auto text-gray-500" />
      </div>
      <h3 className="text-white text-lg mb-2">No Videos Yet</h3>
      <p className="text-gray-400 mb-4">
        Upload your first video to get started
      </p>
      <Button 
        onClick={onUpload}
        className="bg-gradient-to-r from-brand-purple to-brand-neonBlue hover:opacity-90 text-white px-4 py-2 rounded-md"
      >
        Upload Video
      </Button>
    </Card>
  );
};

export default EmptyVideoState;
