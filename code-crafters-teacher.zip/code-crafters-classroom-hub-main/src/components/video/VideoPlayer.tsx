
import { useRef, useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Calendar, Users, Pause, PlayCircle, Volume2, VolumeX } from "lucide-react";
import { VideoLesson } from "@/types/video";

interface VideoPlayerProps {
  isOpen: boolean;
  onClose: () => void;
  video: VideoLesson | null;
}

const VideoPlayer = ({ isOpen, onClose, video }: VideoPlayerProps) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (isOpen && videoRef.current) {
      videoRef.current.play();
      setIsPlaying(true);
    }
  }, [isOpen]);

  const handlePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleMuteToggle = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  if (!video) return null;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="glass border-white/10 max-w-3xl">
        <DialogHeader>
          <DialogTitle className="gradient-text">{video.title}</DialogTitle>
        </DialogHeader>
        <div className="mt-4">
          <div className="relative rounded-lg overflow-hidden bg-black">
            <video
              ref={videoRef}
              src={video.videoUrl}
              className="w-full aspect-video"
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              onEnded={() => setIsPlaying(false)}
              autoPlay
            />
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 text-white hover:bg-white/10 rounded-full"
                    onClick={handlePlayPause}
                  >
                    {isPlaying ? <Pause size={18} /> : <PlayCircle size={18} />}
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 text-white hover:bg-white/10 rounded-full"
                    onClick={handleMuteToggle}
                  >
                    {isMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
                  </Button>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-gray-300">
                    {video.duration}
                  </span>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-white hover:bg-white/10"
                    onClick={onClose}
                  >
                    Close
                  </Button>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-4">
            <h3 className="text-white font-medium mb-2">
              {video.title}
            </h3>
            <div className="flex items-center justify-between text-sm text-gray-400">
              <div className="flex items-center">
                <Calendar size={14} className="mr-1 text-purple-300" />
                <span>{formatDate(video.uploadDate || '')}</span>
              </div>
              <div className="flex items-center">
                <Users size={14} className="mr-1 text-purple-300" />
                <span>{video.views} views</span>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default VideoPlayer;
