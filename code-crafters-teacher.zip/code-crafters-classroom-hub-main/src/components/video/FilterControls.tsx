
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { X } from "lucide-react";

interface FilterControlsProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  activeFilter: string | null;
  onFilterChange: (filter: string | null) => void;
  topics: string[];
}

const FilterControls = ({ searchTerm, onSearchChange, activeFilter, onFilterChange, topics }: FilterControlsProps) => {
  return (
    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
      <div className="relative flex-1 max-w-md">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-300" size={16} />
        <Input 
          placeholder="Search videos..." 
          className="pl-9 glass-input"
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
        />
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex flex-wrap items-center gap-1">
          {topics.map(topic => (
            <Badge 
              key={topic}
              variant={activeFilter === topic ? "gradient" : "outline"}
              className={cn(
                "cursor-pointer", 
                activeFilter === topic ? "animate-pulse-glow" : "hover:bg-white/10"
              )}
              onClick={() => onFilterChange(activeFilter === topic ? null : topic)}
            >
              {topic}
              {activeFilter === topic && (
                <X size={12} className="ml-1 cursor-pointer" />
              )}
            </Badge>
          ))}
        </div>
        <Select defaultValue="date-desc">
          <SelectTrigger className="w-[180px] glass-input">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent className="glass border-white/10">
            <SelectItem value="date-desc">Newest First</SelectItem>
            <SelectItem value="date-asc">Oldest First</SelectItem>
            <SelectItem value="views-desc">Most Viewed</SelectItem>
            <SelectItem value="title-asc">Title (A-Z)</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

export default FilterControls;
