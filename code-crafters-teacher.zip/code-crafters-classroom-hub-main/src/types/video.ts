
export type VideoLesson = {
  id: string;
  title: string;
  thumbnail?: string;
  duration: string;
  uploadDate: string;
  views: number;
  topic: string;
  videoUrl?: string;
};
