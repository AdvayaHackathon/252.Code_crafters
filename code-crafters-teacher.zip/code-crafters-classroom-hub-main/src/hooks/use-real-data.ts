
import { useState, useEffect } from "react";

interface UseRealDataOptions<T> {
  storageKey: string;
  initialData: T;
  onChange?: (data: T) => void;
}

/**
 * Hook to handle real-time data updates using localStorage for persistence
 * and storage events for cross-component communication
 */
export function useRealData<T>({ storageKey, initialData, onChange }: UseRealDataOptions<T>) {
  const [data, setData] = useState<T>(() => {
    const stored = localStorage.getItem(storageKey);
    if (stored) {
      try {
        return JSON.parse(stored) as T;
      } catch (e) {
        console.error(`Error parsing stored data for key ${storageKey}:`, e);
      }
    }
    return initialData;
  });

  // Listen for updates from other components
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === storageKey && e.newValue) {
        try {
          const newData = JSON.parse(e.newValue) as T;
          setData(newData);
          onChange?.(newData);
        } catch (e) {
          console.error(`Error parsing updated data for key ${storageKey}:`, e);
        }
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [storageKey, onChange]);

  // Update storage when data changes
  const updateData = (newData: T | ((prev: T) => T)) => {
    setData(prevData => {
      const updatedData = typeof newData === 'function' 
        ? (newData as ((prev: T) => T))(prevData) 
        : newData;
      
      localStorage.setItem(storageKey, JSON.stringify(updatedData));
      
      // Dispatch a storage event to notify other components
      const event = new StorageEvent('storage', {
        key: storageKey,
        newValue: JSON.stringify(updatedData),
      });
      window.dispatchEvent(event);
      
      return updatedData;
    });
  };

  return [data, updateData] as const;
}
